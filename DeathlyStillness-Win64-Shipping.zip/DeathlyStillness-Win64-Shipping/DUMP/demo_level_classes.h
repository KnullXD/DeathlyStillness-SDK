// BlueprintGeneratedClass demo_level.demo_level_C
// Size: 0x240 (Inherited: 0x228)
struct Ademo_level_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	struct ACameraActor* CameraActor_0_ExecuteUbergraph_demo_level_RefProperty; // 0x230(0x08)
	struct ACameraActor* CameraActor_1_ExecuteUbergraph_demo_level_RefProperty; // 0x238(0x08)

	void Win(); // Function demo_level.demo_level_C.Win // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveBeginPlay(); // Function demo_level.demo_level_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function demo_level.demo_level_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_demo_level(int32_t EntryPoint); // Function demo_level.demo_level_C.ExecuteUbergraph_demo_level // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

