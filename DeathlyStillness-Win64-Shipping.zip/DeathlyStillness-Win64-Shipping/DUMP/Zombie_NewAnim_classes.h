// DynamicClass Zombie_NewAnim.Zombie_NewAnim_C
// Size: 0xf20 (Inherited: 0x2c0)
struct UZombie_NewAnim_C : UAnimInstance {
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2b8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x2e8(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x330(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x358(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x380(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x3a8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x428(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3; // 0x458(0xe8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2; // 0x540(0xc0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x600(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x680(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3; // 0x6b0(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x750(0x80)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2; // 0x7d0(0xe8)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x8b8(0xa0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x958(0x48)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x9a0(0xe8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0xa88(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0xab8(0xb0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0xb68(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0xcc0(0xa0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0xd60(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0xd88(0xc0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0xe48(0x28)
	struct FAnimNode_RandomPlayer AnimGraphNode_RandomPlayer; // 0xe70(0x78)
	bool Attack?; // 0xee8(0x01)
	float Speed; // 0xeec(0x04)
	float StartPosition; // 0xef0(0x04)
	struct AZombie_BP_C* ZombieRef; // 0xef8(0x08)
	bool Hit; // 0xf00(0x01)
	char pad_F02[0x2]; // 0xf02(0x02)
	float Play Rate; // 0xf04(0x04)
	bool Dead?; // 0xf08(0x01)
	char pad_F09[0x3]; // 0xf09(0x03)
	float K2Node_Event_DeltaTimeX; // 0xf0c(0x04)
	struct AZombie_BP_C* K2Node_DynamicCast_AsZombie_BP; // 0xf10(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0xf18(0x01)
	char pad_F19[0x7]; // 0xf19(0x07)

	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_TransitionResult_A64AB1B740F70E86B13501A255E059C7(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_TransitionResult_A64AB1B740F70E86B13501A255E059C7 // (Native|Public) // @ game+0x8d2680
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_TransitionResult_6491645A43DF77BD61AD0F8CF24B140E(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_TransitionResult_6491645A43DF77BD61AD0F8CF24B140E // (Native|Public) // @ game+0x8d2660
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_TransitionResult_52D2615C448DD1582F0142A49C927259(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_TransitionResult_52D2615C448DD1582F0142A49C927259 // (Native|Public) // @ game+0x8d2640
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_SequencePlayer_D5A901A54D6B412151726CA34C708A77(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_SequencePlayer_D5A901A54D6B412151726CA34C708A77 // (Native|Public) // @ game+0x8d2620
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendSpacePlayer_F14879304AAE5DC9E222DCB6C931BB26(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendSpacePlayer_F14879304AAE5DC9E222DCB6C931BB26 // (Native|Public) // @ game+0x8d2600
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendSpacePlayer_D021E0E846EBAF5D65078CB95DD2C63A(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendSpacePlayer_D021E0E846EBAF5D65078CB95DD2C63A // (Native|Public) // @ game+0x8d25e0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendSpacePlayer_A912CE284D27107F4DB003BD7253E53B(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendSpacePlayer_A912CE284D27107F4DB003BD7253E53B // (Native|Public) // @ game+0x8d25c0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendListByBool_EBAB72E847AFC6BF8B48249931BFFC3D(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendListByBool_EBAB72E847AFC6BF8B48249931BFFC3D // (Native|Public) // @ game+0x8d25a0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendListByBool_C9E4C7B54CBDD40B9FB2E4B79A9BB730(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendListByBool_C9E4C7B54CBDD40B9FB2E4B79A9BB730 // (Native|Public) // @ game+0x8d2580
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendListByBool_4FBD06E94F1199AF96D446B48C6490BC(); // Function Zombie_NewAnim.Zombie_NewAnim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Zombie_NewAnim_AnimGraphNode_BlendListByBool_4FBD06E94F1199AF96D446B48C6490BC // (Native|Public) // @ game+0x8d2560
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Function Zombie_NewAnim.Zombie_NewAnim_C.BlueprintUpdateAnimation // (Native|Event|Public) // @ game+0x8d23b0
	void BlueprintInitializeAnimation(); // Function Zombie_NewAnim.Zombie_NewAnim_C.BlueprintInitializeAnimation // (Native|Event|Public) // @ game+0x8d2390
	void AnimNotify_RightFoot(); // Function Zombie_NewAnim.Zombie_NewAnim_C.AnimNotify_RightFoot // (Native|Public|BlueprintCallable) // @ game+0x8d2370
	void AnimNotify_LeftFoot(); // Function Zombie_NewAnim.Zombie_NewAnim_C.AnimNotify_LeftFoot // (Native|Public|BlueprintCallable) // @ game+0x8d2350
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function Zombie_NewAnim.Zombie_NewAnim_C.AnimGraph // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d22b0
};

