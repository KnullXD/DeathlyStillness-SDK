// BlueprintGeneratedClass BP_SQUAD_Sky.BP_SQUAD_Sky_C
// Size: 0x29c (Inherited: 0x220)
struct ABP_SQUAD_Sky_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UStaticMeshComponent* Sky Sphere mesh; // 0x228(0x08)
	struct USceneComponent* Base; // 0x230(0x08)
	struct UMaterialInstanceDynamic* Sky material; // 0x238(0x08)
	bool Refresh material; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct ADirectionalLight* Directional light actor; // 0x248(0x08)
	struct FLinearColor Sun color; // 0x250(0x10)
	float Sun brightness; // 0x260(0x04)
	float Sun height; // 0x264(0x04)
	struct UTexture2D* Sky Texture; // 0x268(0x08)
	float Sun Radius; // 0x270(0x04)
	float Brigntness; // 0x274(0x04)
	float Contrast; // 0x278(0x04)
	float Desaturation; // 0x27c(0x04)
	struct FVector Dome Position Offset; // 0x280(0x0c)
	struct FVector ST_Camera Vector Multiplier; // 0x28c(0x0c)
	float ST_Dome Rotation  Z; // 0x298(0x04)

	void UpdateSunDirection(); // Function BP_SQUAD_Sky.BP_SQUAD_Sky_C.UpdateSunDirection // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void UserConstructionScript(); // Function BP_SQUAD_Sky.BP_SQUAD_Sky_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Refresh(); // Function BP_SQUAD_Sky.BP_SQUAD_Sky_C.Refresh // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_BP_SQUAD_Sky(int32_t EntryPoint); // Function BP_SQUAD_Sky.BP_SQUAD_Sky_C.ExecuteUbergraph_BP_SQUAD_Sky // (Final|UbergraphFunction) // @ game+0x107f740
};

