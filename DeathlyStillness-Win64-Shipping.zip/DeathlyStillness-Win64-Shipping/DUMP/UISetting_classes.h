// BlueprintGeneratedClass UISetting.UISetting_C
// Size: 0x28 (Inherited: 0x28)
struct UUISetting_C : UInterface {

	void Reset(); // Function UISetting.UISetting_C.Reset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
};

