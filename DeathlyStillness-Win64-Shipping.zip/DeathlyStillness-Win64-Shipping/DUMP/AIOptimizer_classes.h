// Class AIOptimizer.AIOBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAIOBPLibrary : UBlueprintFunctionLibrary {

	void SetCharacterMovementEnabled(struct ACharacter* Character, bool bEnable); // Function AIOptimizer.AIOBPLibrary.SetCharacterMovementEnabled // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x87f0d0
	void SetAILogicEnabled(struct AActor* Actor, bool bEnable); // Function AIOptimizer.AIOBPLibrary.SetAILogicEnabled // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x87eeb0
	bool RemoveHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.RemoveHandle // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x87eda0
	bool IsHandleValid(struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.IsHandleValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x87e5c0
	struct FName GetSubjectTag(); // Function AIOptimizer.AIOBPLibrary.GetSubjectTag // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x87e570
	struct FString GetString(struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.GetString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x87e3b0
	struct FName GetInvokerTag(); // Function AIOptimizer.AIOBPLibrary.GetInvokerTag // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x87e2c0
	int32_t FindHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& HandleToFind); // Function AIOptimizer.AIOBPLibrary.FindHandle // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x87dc80
	int32_t AddUniqueHandle(struct TArray<struct FAIOSubjectHandle>& Array, struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOBPLibrary.AddUniqueHandle // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x87dab0
};

// Class AIOptimizer.AIOData_Base
// Size: 0x28 (Inherited: 0x28)
struct UAIOData_Base : UObject {
};

// Class AIOptimizer.AIODeveloperSettings
// Size: 0x60 (Inherited: 0x38)
struct UAIODeveloperSettings : UDeveloperSettings {
	char bIsSubsystemEnabled : 1; // 0x38(0x01)
	char bDisplayDebugInfo : 1; // 0x38(0x01)
	char pad_38_2 : 6; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct UUserWidget* DebugWidgetClass; // 0x40(0x08)
	float OptimizationUpdateInterval; // 0x48(0x04)
	enum class EDespawnMethod HandleSpawnDespawnMethod; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	int32_t SpawnCapacityPerUpdate; // 0x50(0x04)
	float SpawnInterval; // 0x54(0x04)
	float DespawnRadius; // 0x58(0x04)
	float PeripheralVisionHalfAngleDegrees; // 0x5c(0x04)
};

// Class AIOptimizer.AIOInvokerComponent
// Size: 0xb8 (Inherited: 0xb0)
struct UAIOInvokerComponent : UActorComponent {
	struct UUserWidget* DebugWidget; // 0xb0(0x08)

	void DebugAIOptimizer(bool bDebug); // Function AIOptimizer.AIOInvokerComponent.DebugAIOptimizer // (Final|Native|Public|BlueprintCallable) // @ game+0x87dbf0
};

// Class AIOptimizer.AIOptimizerSubsystem
// Size: 0xc8 (Inherited: 0x30)
struct UAIOptimizerSubsystem : UWorldSubsystem {
	struct FMulticastInlineDelegate OnSubjectDespawned; // 0x30(0x10)
	struct FMulticastInlineDelegate OnSubjectSpawned; // 0x40(0x10)
	struct FMulticastInlineDelegate OnSubsystemEnabledChanged; // 0x50(0x10)
	struct TArray<struct FAIOSubject> SpawnedSubjects; // 0x60(0x10)
	struct TArray<struct FAIODespawnedSubject> DespawnedSubjects; // 0x70(0x10)
	struct TArray<struct FAIOInvoker> Invokers; // 0x80(0x10)
	struct TArray<struct FAIOSubject> PendingDespawnSubjectsHeap; // 0x90(0x10)
	struct TArray<struct FAIODespawnedSubject> PendingSpawnSubjectsHeap; // 0xa0(0x10)
	char pad_B0[0x18]; // 0xb0(0x18)

	bool UnregisterSubject(struct UAIOSubjectComponent* SubjectComponent); // Function AIOptimizer.AIOptimizerSubsystem.UnregisterSubject // (Final|Native|Public|BlueprintCallable) // @ game+0x87f480
	bool UnregisterInvoker(struct UAIOInvokerComponent* InvokerComponent); // Function AIOptimizer.AIOptimizerSubsystem.UnregisterInvoker // (Final|Native|Public|BlueprintCallable) // @ game+0x87f3c0
	void ShrinkArrays(); // Function AIOptimizer.AIOptimizerSubsystem.ShrinkArrays // (Final|Native|Protected) // @ game+0x87f3a0
	void SetIsSystemEnabled(bool bIsEnabled); // Function AIOptimizer.AIOptimizerSubsystem.SetIsSystemEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x87f190
	bool RemoveDespawnedSubjectByHandle(struct FAIOSubjectHandle& Handle); // Function AIOptimizer.AIOptimizerSubsystem.RemoveDespawnedSubjectByHandle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87ecf0
	bool RegisterSubject(struct UAIOSubjectComponent* SubjectComponent); // Function AIOptimizer.AIOptimizerSubsystem.RegisterSubject // (Final|Native|Public|BlueprintCallable) // @ game+0x87eba0
	bool RegisterInvoker(struct UAIOInvokerComponent* InvokerComponent); // Function AIOptimizer.AIOptimizerSubsystem.RegisterInvoker // (Final|Native|Public|BlueprintCallable) // @ game+0x87eae0
	void LoopSubjects(); // Function AIOptimizer.AIOptimizerSubsystem.LoopSubjects // (Final|Native|Protected) // @ game+0x87eac0
	void LoopPendingSubjects(); // Function AIOptimizer.AIOptimizerSubsystem.LoopPendingSubjects // (Final|Native|Protected) // @ game+0x87eaa0
	bool K2_SpawnSubjectByHandle(enum class EDespawnMethod Method, struct FAIOSubjectHandle& SubjectHandle); // Function AIOptimizer.AIOptimizerSubsystem.K2_SpawnSubjectByHandle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87e9c0
	bool K2_DespawnSubjectByHandle(struct FAIOSubjectHandle& SubjectHandle, enum class EDespawnMethod Method, float OverrideSpawnRadius, bool bAllowRespawnOnlyByHandle); // Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubjectByHandle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87e840
	bool K2_DespawnSubject(struct FAIOSubjectHandle& SubjectHandle, enum class EDespawnMethod Method, struct UAIOSubjectComponent* Component, float OverrideSpawnRadius, bool bAllowRespawnOnlyByHandle); // Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87e670
	int32_t GetSubjectIndex(struct UAIOSubjectComponent* Component); // Function AIOptimizer.AIOptimizerSubsystem.GetSubjectIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x87e4a0
	int32_t GetInvokerIndex(struct UAIOInvokerComponent* Component); // Function AIOptimizer.AIOptimizerSubsystem.GetInvokerIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x87e1f0
	float GetDistanceToClosestInvokerSquared(struct FVector& QuerierLocation); // Function AIOptimizer.AIOptimizerSubsystem.GetDistanceToClosestInvokerSquared // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x87e150
	struct TArray<struct FAIODebugSubjectData> GetDebugSubjects(); // Function AIOptimizer.AIOptimizerSubsystem.GetDebugSubjects // (Final|Native|Public|BlueprintCallable) // @ game+0x87e000
	struct FVector GetClosestInvokerLocation(struct FVector& QuerierLocation); // Function AIOptimizer.AIOptimizerSubsystem.GetClosestInvokerLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x87df30
	struct TMap<enum class EAIODebugGroup, int32_t> GetCategorizedDebugSubjects(struct TArray<struct FAIODebugSubjectData>& DebugSubjects); // Function AIOptimizer.AIOptimizerSubsystem.GetCategorizedDebugSubjects // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87ddc0
};

// Class AIOptimizer.AIOSubjectComponent
// Size: 0x148 (Inherited: 0xb0)
struct UAIOSubjectComponent : UActorComponent {
	char pad_B0[0x1c]; // 0xb0(0x1c)
	struct FAIOSubjectHandle Handle; // 0xcc(0x04)
	char pad_D0[0x8]; // 0xd0(0x08)
	struct FMulticastInlineDelegate OnOptimizationUpdate; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnPreDespawn; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnPostSpawned; // 0xf8(0x10)
	struct AActor* Spawner; // 0x108(0x08)
	char bCanBeUpdatedBySubsystem : 1; // 0x110(0x01)
	char bAllowSubsystemToAutoDespawn : 1; // 0x110(0x01)
	char pad_110_2 : 6; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	float OverrideSubsystemDespawnRadius; // 0x114(0x04)
	char Priority; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
	struct UAIOData_Base* DataClass; // 0x120(0x08)
	struct TArray<struct FAIOptimizationLayer> OptimizationLayers; // 0x128(0x10)
	char bShouldCalculateIsSeen : 1; // 0x138(0x01)
	char pad_138_1 : 7; // 0x138(0x01)
	char pad_139[0xf]; // 0x139(0x0f)

	void UnregisterSubject(); // Function AIOptimizer.AIOSubjectComponent.UnregisterSubject // (Final|Native|Public|BlueprintCallable) // @ game+0x87f460
	bool ShouldBeDespawned(struct UAIOptimizerSubsystem* Subsystem, bool bForceUpdateDataToInvokers); // Function AIOptimizer.AIOSubjectComponent.ShouldBeDespawned // (Native|Event|Public|BlueprintEvent) // @ game+0x87f2c0
	void SetSpawner(struct TScriptInterface<ISpawnerInterface> NewSpawner); // Function AIOptimizer.AIOSubjectComponent.SetSpawner // (Final|Native|Public|BlueprintCallable) // @ game+0x87f220
	void SetCharacterFeatures(struct ACharacter* Character, int32_t FeaturesToEnable); // Function AIOptimizer.AIOSubjectComponent.SetCharacterFeatures // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x87f000
	void SetCanBeUpdatedBySubsystem(bool bCanBeUpdated); // Function AIOptimizer.AIOSubjectComponent.SetCanBeUpdatedBySubsystem // (Final|Native|Public|BlueprintCallable) // @ game+0x87ef70
	void ReinitializeOptimizationLayers(struct TArray<struct FAIOptimizationLayer>& NewOptimizationLayers); // Function AIOptimizer.AIOSubjectComponent.ReinitializeOptimizationLayers // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x87ec40
	void RegisterSubject(); // Function AIOptimizer.AIOSubjectComponent.RegisterSubject // (Final|Native|Public|BlueprintCallable) // @ game+0x87eb80
	float IsSeenByAnyInvoker(); // Function AIOptimizer.AIOSubjectComponent.IsSeenByAnyInvoker // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87e640
	bool IsDespawning(); // Function AIOptimizer.AIOSubjectComponent.IsDespawning // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87e590
	float GetSpawnRadiusSquared(struct UAIOptimizerSubsystem* Subsystem); // Function AIOptimizer.AIOSubjectComponent.GetSpawnRadiusSquared // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x87e310
	int32_t GetOptimizationLayerForCurrentDistance(); // Function AIOptimizer.AIOSubjectComponent.GetOptimizationLayerForCurrentDistance // (Final|Native|Public|BlueprintCallable) // @ game+0x87e2e0
	float GetDistanceToClosestInvoker(); // Function AIOptimizer.AIOSubjectComponent.GetDistanceToClosestInvoker // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87e120
	float GetDespawnRadiusSquared(struct UAIOptimizerSubsystem* Subsystem); // Function AIOptimizer.AIOSubjectComponent.GetDespawnRadiusSquared // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x87e080
	int32_t GetCurrentOptimizationLayer(); // Function AIOptimizer.AIOSubjectComponent.GetCurrentOptimizationLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87dfe0
	struct FVector GetClosestInvokerLocation(); // Function AIOptimizer.AIOSubjectComponent.GetClosestInvokerLocation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x87df00
	bool CanBeUpdatedBySubsystem(); // Function AIOptimizer.AIOSubjectComponent.CanBeUpdatedBySubsystem // (Native|Event|Public|BlueprintEvent) // @ game+0x87dbc0
};

// Class AIOptimizer.SpawnerInterface
// Size: 0x28 (Inherited: 0x28)
struct USpawnerInterface : UInterface {

	void OnSubjectSpawnedByOptimizerSubsystem(struct UAIOSubjectComponent* SpawnedSubjectComponent); // Function AIOptimizer.SpawnerInterface.OnSubjectSpawnedByOptimizerSubsystem // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void OnSubjectDespawnedByOptimizerSubsystem(struct UAIOSubjectComponent* DespawnedSubjectComponent); // Function AIOptimizer.SpawnerInterface.OnSubjectDespawnedByOptimizerSubsystem // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
};

