// Class DatasmithGLTFTranslator.DatasmithGLTFImportOptions
// Size: 0x30 (Inherited: 0x28)
struct UDatasmithGLTFImportOptions : UDatasmithOptionsBase {
	bool bGenerateLightmapUVs; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float ImportScale; // 0x2c(0x04)
};

