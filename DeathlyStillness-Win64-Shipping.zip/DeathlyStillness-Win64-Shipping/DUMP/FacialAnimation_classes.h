// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x8a0 (Inherited: 0x860)
struct UAudioCurveSourceComponent : UAudioComponent {
	char pad_860[0x8]; // 0x860(0x08)
	struct FName CurveSourceBindingName; // 0x868(0x08)
	float CurveSyncOffset; // 0x870(0x04)
	char pad_874[0x2c]; // 0x874(0x2c)
};

