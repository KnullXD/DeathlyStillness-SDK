// Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAutomationUtilsBlueprintLibrary : UBlueprintFunctionLibrary {

	void TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride); // Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x91fc70
};

