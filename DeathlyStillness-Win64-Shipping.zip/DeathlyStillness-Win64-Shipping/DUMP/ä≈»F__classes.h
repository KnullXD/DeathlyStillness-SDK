// BlueprintGeneratedClass 主F . ��界 
// Size: 0x238 (Inherited: 0x220)
struct A ��界  : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UAudioComponent* Audio; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)

	void  ��换 (struct USoundBase* NewSound); // Function 主F . ��界 . ��换  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_主Cl(int32_t EntryPoint); // Function 主F . ��界 . xecuteUbergraph_主Cl // (Final|UbergraphFunction) // @ game+0x107f740
};

