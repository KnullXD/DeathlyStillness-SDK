// BlueprintGeneratedClass 中b. ��国老巷Qu
// Size: 0x248 (Inherited: 0x220)
struct A ��国老巷Qu : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
	enum class ChineseAlley_Quest Quest; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct APlayer_BP_C* PlayerRef; // 0x238(0x08)
	struct AChinese_Vampire_BP_C* ChineseVcampireRef; // 0x240(0x08)

	void ReceiveBeginPlay(); // Function 中b. ��国老巷Qu.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function 中b. ��国老巷Qu. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_中国老巷(int32_t EntryPoint); // Function 中b. ��国老巷Qu. xecuteUbergraph_中国老巷 // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

