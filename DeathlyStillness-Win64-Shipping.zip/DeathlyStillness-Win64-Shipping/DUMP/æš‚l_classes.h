// WidgetBlueprintGeneratedClass 暂l. ��停
// Size: 0x2b0 (Inherited: 0x260)
struct U ��停 : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* 1; // 0x268(0x08)
	struct UCanvasPanel* Pause; // 0x270(0x08)
	struct UTextBlock* TextBlock; // 0x278(0x08)
	struct UTextBlock* TextBlock_51; // 0x280(0x08)
	struct U ��钮*  �� ; // 0x288(0x08)
	struct U ��钮*  �� _2; // 0x290(0x08)
	struct U ��钮*  �� _3; // 0x298(0x08)
	struct U ��置U*  ��  ; // 0x2a0(0x08)
	struct APlayer_BP_C* Player ; // 0x2a8(0x08)

	void  ��闭  (); // Function 暂l. ��停. ��闭   // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Construct(); // Function 暂l. ��停.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void No(); // Function 暂l. ��停.No // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Yes(); // Function 暂l. ��停.Yes // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Setting(); // Function 暂l. ��停.Setting // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  nClicked_  _1(); // Function 暂l. ��停. nClicked_  _1 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_暂C(int32_t EntryPoint); // Function 暂l. ��停. xecuteUbergraph_暂C // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

