// BlueprintGeneratedClass SCARBullet_BP.SCARBullet_BP_C
// Size: 0x254 (Inherited: 0x254)
struct ASCARBullet_BP_C : ABulletMaster_BP_C {
};

