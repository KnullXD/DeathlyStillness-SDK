// BlueprintGeneratedClass PlayerStateSetting.PlayerStateSetting_C
// Size: 0x34 (Inherited: 0x28)
struct UPlayerStateSetting_C : USaveGame {
	int32_t MouseX; // 0x28(0x04)
	int32_t MouseY; // 0x2c(0x04)
	int32_t BgmSoundScale; // 0x30(0x04)
};

