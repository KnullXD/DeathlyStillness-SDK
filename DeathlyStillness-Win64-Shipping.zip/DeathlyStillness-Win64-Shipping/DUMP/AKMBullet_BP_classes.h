// BlueprintGeneratedClass AKMBullet_BP.AKMBullet_BP_C
// Size: 0x254 (Inherited: 0x254)
struct AAKMBullet_BP_C : ABulletMaster_BP_C {
};

