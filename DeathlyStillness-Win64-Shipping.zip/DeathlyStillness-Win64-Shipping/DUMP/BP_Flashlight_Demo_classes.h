// BlueprintGeneratedClass BP_Flashlight_Demo.BP_Flashlight_Demo_C
// Size: 0x2c0 (Inherited: 0x280)
struct ABP_Flashlight_Demo_C : APawn {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x280(0x08)
	struct UStaticMeshComponent* Static Mesh Flashlight; // 0x288(0x08)
	struct UStaticMesh* Mesh; // 0x290(0x08)
	bool ON; // 0x298(0x01)
	char pad_299[0x3]; // 0x299(0x03)
	float Intensity; // 0x29c(0x04)
	float Light Intensity Multiplier; // 0x2a0(0x04)
	float Outer Cone Angle; // 0x2a4(0x04)
	float Inner Cone Angle; // 0x2a8(0x04)
	struct FColor Light Color; // 0x2ac(0x04)
	struct UPointLightComponent* Light Source 1; // 0x2b0(0x08)
	struct UTexture* Spotlight Beam Texture; // 0x2b8(0x08)

	void Set Intensity(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.Set Intensity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void UserConstructionScript(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void TurnOn(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.TurnOn // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void TurnOff(); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.TurnOff // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_BP_Flashlight_Demo(int32_t EntryPoint); // Function BP_Flashlight_Demo.BP_Flashlight_Demo_C.ExecuteUbergraph_BP_Flashlight_Demo // (Final|UbergraphFunction) // @ game+0x107f740
};

