// Enum ChineseAll.ChineseAlley_Quest
enum class ChineseAlley_Quest : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	NewEnumerator4 = 3,
	NewEnumerator5 = 4,
	ChineseAlley_MAX = 5
};

