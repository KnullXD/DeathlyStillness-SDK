// BlueprintGeneratedClass Sprint_CameraShake.Sprint_CameraShake_C
// Size: 0x180 (Inherited: 0x180)
struct USprint_CameraShake_C : UMatineeCameraShake {
};

