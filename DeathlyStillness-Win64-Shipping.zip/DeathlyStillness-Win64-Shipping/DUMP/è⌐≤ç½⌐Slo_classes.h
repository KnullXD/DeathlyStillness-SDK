// WidgetBlueprintGeneratedClass 设置Slo. ��置SlotU
// Size: 0x3d5 (Inherited: 0x260)
struct U ��置SlotU : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_52; // 0x268(0x08)
	struct UImage* Left; // 0x270(0x08)
	struct UButton* LeftButton; // 0x278(0x08)
	struct UImage* Right; // 0x280(0x08)
	struct UButton* RightButton; // 0x288(0x08)
	struct UTextBlock* TextBlock_91; // 0x290(0x08)
	struct UTextBlock* TextBlock_341; // 0x298(0x08)
	bool IsClick; // 0x2a0(0x01)
	enum class SettingEnum SettingEnum; // 0x2a1(0x01)
	char pad_2A2[0x6]; // 0x2a2(0x06)
	struct FString  �� ; // 0x2a8(0x10)
	struct FText SettingText; // 0x2b8(0x18)
	struct FText SettingMode; // 0x2d0(0x18)
	struct TArray<struct FString>  ��  ; // 0x2e8(0x10)
	int32_t  ��幕分 ; // 0x2f8(0x04)
	int32_t  ��视距; // 0x2fc(0x04)
	struct FString  ave可 ; // 0x300(0x10)
	struct FString   ; // 0x310(0x10)
	int32_t  ��锯  ; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)
	struct FString  ave抗; // 0x328(0x10)
	int32_t  ��期处  ; // 0x338(0x04)
	char pad_33C[0x4]; // 0x33c(0x04)
	struct FString  ave后期; // 0x340(0x10)
	struct USaveSetting_C* SaveSettingRef; // 0x350(0x08)
	int32_t  ��影质; // 0x358(0x04)
	char pad_35C[0x4]; // 0x35c(0x04)
	struct FString  ave阴 ; // 0x360(0x10)
	int32_t  ��理质; // 0x370(0x04)
	char pad_374[0x4]; // 0x374(0x04)
	struct FString  ave纹 ; // 0x378(0x10)
	int32_t  ��被质; // 0x388(0x04)
	char pad_38C[0x4]; // 0x38c(0x04)
	struct FString  ave植 ; // 0x390(0x10)
	bool  ��  ; // 0x3a0(0x01)
	char pad_3A1[0x7]; // 0x3a1(0x07)
	struct FString FPSclamp; // 0x3a8(0x10)
	int32_t FPSIndex; // 0x3b8(0x04)
	char pad_3BC[0x4]; // 0x3bc(0x04)
	struct FString SaveFOV; // 0x3c0(0x10)
	int32_t FOVIndex; // 0x3d0(0x04)
	bool FullScreen?; // 0x3d4(0x01)

	void  ��存显(); // Function 设置Slo. ��置SlotU. ��存显 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存F(); // Function 设置Slo. ��置SlotU. ��存F // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��  (int32_t& Index, struct FString  , struct FString  , struct FString  , struct FString   ); // Function 设置Slo. ��置SlotU. ��   // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��  (int32_t& Index, struct FString  , struct FString  , struct FString  , struct FString   ); // Function 设置Slo. ��置SlotU. ��   // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存F(); // Function 设置Slo. ��置SlotU. ��存F // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��  (int32_t& Index, struct FString  , struct FString  , struct FString  , struct FString   , struct FString&   ); // Function 设置Slo. ��置SlotU. ��   // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��  (int32_t& Index, struct FString  , struct FString  , struct FString  , struct FString   , struct FString& FPS); // Function 设置Slo. ��置SlotU. ��   // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存  (); // Function 设置Slo. ��置SlotU. ��存   // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存  (); // Function 设置Slo. ��置SlotU. ��存   // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存  (); // Function 设置Slo. ��置SlotU. ��存   // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存后 (); // Function 设置Slo. ��置SlotU. ��存后  // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存 (); // Function 设置Slo. ��置SlotU. ��存  // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��存  (); // Function 设置Slo. ��置SlotU. ��存   // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (int32_t& Index, struct FString  , struct FString  , struct FString  , struct FString   , struct FString&   ); // Function 设置Slo. ��置SlotU. ��  // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (int32_t& Index, struct FString  , struct FString  , struct FString  , struct FString   , struct FString&   ); // Function 设置Slo. ��置SlotU. ��  // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��  (); // Function 设置Slo. ��置SlotU. ��   // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��改(struct FText  �� , bool FullScreen?); // Function 设置Slo. ��置SlotU. ��改 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��入(); // Function 设置Slo. ��置SlotU. ��入 // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function 设置Slo. ��置SlotU.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Construct(); // Function 设置Slo. ��置SlotU.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function 设置Slo. ��置SlotU.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x107f740
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Function 设置Slo. ��置SlotU.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_188_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function 设置Slo. ��置SlotU.BndEvt__Button_188_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function 设置Slo. ��置SlotU.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void Reset(); // Function 设置Slo. ��置SlotU.Reset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_设置Slo(int32_t EntryPoint); // Function 设置Slo. ��置SlotU. xecuteUbergraph_设置Slo // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

