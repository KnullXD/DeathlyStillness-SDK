// Enum QuestType.QuestType
enum class QuestType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	QuestType_MAX = 2
};

