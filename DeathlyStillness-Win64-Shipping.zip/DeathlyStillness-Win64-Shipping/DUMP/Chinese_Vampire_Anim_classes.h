// AnimBlueprintGeneratedClass Chinese_Vampire_Anim.Chinese_Vampire_Anim_C
// Size: 0xa18 (Inherited: 0x2c0)
struct UChinese_Vampire_Anim_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x2f8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x320(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x348(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x370(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x3f0(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2; // 0x420(0xe8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x508(0xc0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x5c8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x648(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x678(0xe8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x760(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x790(0xb0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x840(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x998(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x9c0(0x48)
	float Speed; // 0xa08(0x04)
	bool Dead?; // 0xa0c(0x01)
	bool Hit; // 0xa0d(0x01)
	char pad_A0E[0x2]; // 0xa0e(0x02)
	struct AChinese_Vampire_BP_C* As Chinese Vampire BP; // 0xa10(0x08)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Chinese_Vampire_Anim_AnimGraphNode_TransitionResult_EB9E32154ACFBB550C2A05A05D2169BC // (BlueprintEvent) // @ game+0x107f740
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x107f740
	void AnimNotify_Footstep(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.AnimNotify_Footstep // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void BlueprintInitializeAnimation(); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.BlueprintInitializeAnimation // (Event|Public|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Chinese_Vampire_Anim(int32_t EntryPoint); // Function Chinese_Vampire_Anim.Chinese_Vampire_Anim_C.ExecuteUbergraph_Chinese_Vampire_Anim // (Final|UbergraphFunction) // @ game+0x107f740
};

