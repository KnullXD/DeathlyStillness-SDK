// DynamicClass Zombie_Spawner.Zombie_Spawner_C
// Size: 0x280 (Inherited: 0x220)
struct AZombie_Spawner_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x220(0x08)
	int32_t  ��机; // 0x228(0x04)
	float Min; // 0x22c(0x04)
	float Max; // 0x230(0x04)
	char pad_234[0x4]; // 0x234(0x04)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors; // 0x238(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0x248(0x10)
	struct AActor* CallFunc_Array_Get_Item; // 0x258(0x08)
	int32_t ___int_Variable; // 0x260(0x04)
	char pad_264[0x4]; // 0x264(0x04)
	struct AZombie_BP_C* K2Node_DynamicCast_AsZombie_BP; // 0x268(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x270(0x01)
	char pad_271[0x7]; // 0x271(0x07)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue; // 0x278(0x08)

	void  ��机选 (); // Function Zombie_Spawner.Zombie_Spawner_C. ��机选  // (Native|Public|BlueprintCallable) // @ game+0x8d33e0
	void  �� (); // Function Zombie_Spawner.Zombie_Spawner_C. ��  // (Native|Public|BlueprintCallable) // @ game+0x8d33c0
	void Stop(); // Function Zombie_Spawner.Zombie_Spawner_C.Stop // (Native|Public|BlueprintCallable) // @ game+0x8d33a0
};

