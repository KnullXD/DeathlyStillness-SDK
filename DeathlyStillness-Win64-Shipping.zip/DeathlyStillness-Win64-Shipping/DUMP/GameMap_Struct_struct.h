// ScriptStruct GameMap_Struct.GameMap_Struct
// Size: 0x70 (Inherited: 0x00)
struct FGameMap_Struct {
	struct TArray<struct UTexture2D*>  ��景图片_3_91C0EA554E509B49539B56A1; // 0x00(0x10)
	struct FText  ��图介绍_14_AC549D9B495AEEC2E75FF88F; // 0x10(0x18)
	struct FText  ��务介绍_15_8B02C7EC453764F44A0CEDA3; // 0x28(0x18)
	struct FText  ��节_17_254785B24D628055DAC18B822F51; // 0x40(0x18)
	struct FText  ��引帮助_19_CF31A2CC40DF1E48AB6B3C8D; // 0x58(0x18)
};

