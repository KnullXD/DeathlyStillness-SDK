// BlueprintGeneratedClass Ammo_BP.Ammo_BP_C
// Size: 0x261 (Inherited: 0x220)
struct AAmmo_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UBoxComponent* Box; // 0x228(0x08)
	struct USphereComponent* Sphere1; // 0x230(0x08)
	struct UWidgetComponent*  �� ; // 0x238(0x08)
	struct UWidgetComponent*  �� ; // 0x240(0x08)
	struct UStaticMeshComponent* Ammo; // 0x248(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x250(0x08)
	struct APlayer_BP_C* PlayerRef; // 0x258(0x08)
	bool IsOverlap; // 0x260(0x01)

	void ReceiveBeginPlay(); // Function Ammo_BP.Ammo_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void RenderDeepClose(); // Function Ammo_BP.Ammo_BP_C.RenderDeepClose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void RenderDeepOpen(); // Function Ammo_BP.Ammo_BP_C.RenderDeepOpen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Pickup(); // Function Ammo_BP.Ammo_BP_C.Pickup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void BndEvt__Ammo_BP_Sphere1_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function Ammo_BP.Ammo_BP_C.BndEvt__Ammo_BP_Sphere1_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x107f740
	void BndEvt__Ammo_BP_Sphere1_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function Ammo_BP.Ammo_BP_C.BndEvt__Ammo_BP_Sphere1_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Ammo_BP(int32_t EntryPoint); // Function Ammo_BP.Ammo_BP_C.ExecuteUbergraph_Ammo_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

