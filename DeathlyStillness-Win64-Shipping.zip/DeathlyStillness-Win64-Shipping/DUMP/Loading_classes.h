// WidgetBlueprintGeneratedClass Loading.Loading_C
// Size: 0x308 (Inherited: 0x260)
struct ULoading_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Flask; // 0x268(0x08)
	struct UWidgetAnimation* Appear; // 0x270(0x08)
	struct UImage* Image_46; // 0x278(0x08)
	struct UImage* Image_137; // 0x280(0x08)
	struct UImage* Image_223; // 0x288(0x08)
	struct UProgressBar* ProgressBar_169; // 0x290(0x08)
	struct UTextBlock* TextBlock_137; // 0x298(0x08)
	float Time; // 0x2a0(0x04)
	struct FName GameMap; // 0x2a4(0x08)
	bool IsReStart?; // 0x2ac(0x01)
	char pad_2AD[0x3]; // 0x2ad(0x03)
	struct UTexture2D* LoadingTexture; // 0x2b0(0x08)
	struct TMap<struct FName, struct FGameMap_Struct>  �� ; // 0x2b8(0x50)

	void Construct(); // Function Loading.Loading_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void Loading(); // Function Loading.Loading_C.Loading // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Loading(int32_t EntryPoint); // Function Loading.Loading_C.ExecuteUbergraph_Loading // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

