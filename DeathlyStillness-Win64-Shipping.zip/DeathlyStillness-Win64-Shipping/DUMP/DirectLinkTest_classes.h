// Class DirectLinkTest.DirectLinkTestLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDirectLinkTestLibrary : UBlueprintFunctionLibrary {

	bool TestParameters(); // Function DirectLinkTest.DirectLinkTestLibrary.TestParameters // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8880
	bool StopSender(); // Function DirectLinkTest.DirectLinkTestLibrary.StopSender // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8850
	bool StopReceiver(); // Function DirectLinkTest.DirectLinkTestLibrary.StopReceiver // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8820
	bool StartSender(); // Function DirectLinkTest.DirectLinkTestLibrary.StartSender // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b87f0
	bool StartReceiver(); // Function DirectLinkTest.DirectLinkTestLibrary.StartReceiver // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b87c0
	bool SetupSender(); // Function DirectLinkTest.DirectLinkTestLibrary.SetupSender // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8790
	bool SetupReceiver(); // Function DirectLinkTest.DirectLinkTestLibrary.SetupReceiver // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8760
	bool SendScene(struct FString InFilePath); // Function DirectLinkTest.DirectLinkTestLibrary.SendScene // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b86c0
	int32_t MakeEndpoint(struct FString NiceName, bool bVerbose); // Function DirectLinkTest.DirectLinkTestLibrary.MakeEndpoint // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b85e0
	bool DumpReceivedScene(); // Function DirectLinkTest.DirectLinkTestLibrary.DumpReceivedScene // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b85b0
	bool DeleteEndpoint(int32_t EndpointId); // Function DirectLinkTest.DirectLinkTestLibrary.DeleteEndpoint // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8520
	bool DeleteAllEndpoint(); // Function DirectLinkTest.DirectLinkTestLibrary.DeleteAllEndpoint // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b84f0
	bool AddPublicSource(int32_t EndpointId, struct FString SourceName); // Function DirectLinkTest.DirectLinkTestLibrary.AddPublicSource // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b83c0
	bool AddPublicDestination(int32_t EndpointId, struct FString DestName); // Function DirectLinkTest.DirectLinkTestLibrary.AddPublicDestination // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7b8290
};

