// BlueprintGeneratedClass Clip_Master.Clip_Master_C
// Size: 0x238 (Inherited: 0x220)
struct AClip_Master_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)

	void Reload(); // Function Clip_Master.Clip_Master_C.Reload // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Clip_Master(int32_t EntryPoint); // Function Clip_Master.Clip_Master_C.ExecuteUbergraph_Clip_Master // (Final|UbergraphFunction) // @ game+0x107f740
};

