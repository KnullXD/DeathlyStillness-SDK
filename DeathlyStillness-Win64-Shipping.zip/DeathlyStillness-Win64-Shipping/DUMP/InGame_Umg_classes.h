// WidgetBlueprintGeneratedClass InGame_Umg.InGame_Umg_C
// Size: 0x390 (Inherited: 0x260)
struct UInGame_Umg_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation*  ��星; // 0x268(0x08)
	struct UWidgetAnimation* HitHeadTip; // 0x270(0x08)
	struct UWidgetAnimation* Dead; // 0x278(0x08)
	struct UWidgetAnimation* Kick; // 0x280(0x08)
	struct UWidgetAnimation* HitMarkerAnimation; // 0x288(0x08)
	struct UWidgetAnimation* HitMarkerAnimationHead; // 0x290(0x08)
	struct UWidgetAnimation* KeyBoardTip; // 0x298(0x08)
	struct UWidgetAnimation* QuestStart; // 0x2a0(0x08)
	struct UWidgetAnimation* Quest; // 0x2a8(0x08)
	struct UWidgetAnimation* ScreenDamage; // 0x2b0(0x08)
	struct UCanvasPanel* CrossHair; // 0x2b8(0x08)
	struct UImage* Down; // 0x2c0(0x08)
	struct UCanvasPanel* Health; // 0x2c8(0x08)
	struct UImage* Image; // 0x2d0(0x08)
	struct UImage* Image_1; // 0x2d8(0x08)
	struct UImage* Image_2; // 0x2e0(0x08)
	struct UImage* Image_11; // 0x2e8(0x08)
	struct UImage* Image_50; // 0x2f0(0x08)
	struct UImage* Image_65; // 0x2f8(0x08)
	struct UImage* Image_88; // 0x300(0x08)
	struct UImage* Image_89; // 0x308(0x08)
	struct UImage* Image_263; // 0x310(0x08)
	struct UImage* Left; // 0x318(0x08)
	struct UProgressBar* ProgressBar_186; // 0x320(0x08)
	struct UImage* Right; // 0x328(0x08)
	struct UTextBlock* TextBlock_2; // 0x330(0x08)
	struct UTextBlock* TextBlock_3; // 0x338(0x08)
	struct UTextBlock* TextBlock_4; // 0x340(0x08)
	struct UTextBlock* TextBlock_108; // 0x348(0x08)
	struct UTextBlock* TextBlock_209; // 0x350(0x08)
	struct UTextBlock* TextBlock_347; // 0x358(0x08)
	struct UTextBlock* TextBlock_414; // 0x360(0x08)
	struct UTextBlock* TextBlock_465; // 0x368(0x08)
	struct UTextBlock* TextBlock_650; // 0x370(0x08)
	struct UImage* Top; // 0x378(0x08)
	struct APlayer_BP_C* PlayerRef; // 0x380(0x08)
	int32_t ZombieNum; // 0x388(0x04)
	int32_t BulletNum; // 0x38c(0x04)

	struct FText GetText_3(); // Function InGame_Umg.InGame_Umg_C.GetText_3 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	struct FText GetText_1(); // Function InGame_Umg.InGame_Umg_C.GetText_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	struct FLinearColor GetFillColorAndOpacity_1(); // Function InGame_Umg.InGame_Umg_C.GetFillColorAndOpacity_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	float GetPercent_1(); // Function InGame_Umg.InGame_Umg_C.GetPercent_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	struct FText GetText_2(); // Function InGame_Umg.InGame_Umg_C.GetText_2 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	void QuestTip_Evenet(); // Function InGame_Umg.InGame_Umg_C.QuestTip_Evenet // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void keyBoardTip_event(enum class EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.keyBoardTip_event // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void QuestStart_Event(); // Function InGame_Umg.InGame_Umg_C.QuestStart_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void HitHead(); // Function InGame_Umg.InGame_Umg_C.HitHead // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void DamageEffect(); // Function InGame_Umg.InGame_Umg_C.DamageEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void HitZombie(); // Function InGame_Umg.InGame_Umg_C.HitZombie // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function InGame_Umg.InGame_Umg_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void   (enum class EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.   // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Construct(); // Function InGame_Umg.InGame_Umg_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void DeadScreen(); // Function InGame_Umg.InGame_Umg_C.DeadScreen // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (enum class ESlateVisibility  , enum class ESlateVisibility   ); // Function InGame_Umg.InGame_Umg_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function InGame_Umg.InGame_Umg_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��击(); // Function InGame_Umg.InGame_Umg_C. ��击 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void CrosshairFade(enum class EUMGSequencePlayMode PlayMode); // Function InGame_Umg.InGame_Umg_C.CrosshairFade // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_InGame_Umg(int32_t EntryPoint); // Function InGame_Umg.InGame_Umg_C.ExecuteUbergraph_InGame_Umg // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

