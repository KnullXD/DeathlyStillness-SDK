// DynamicClass At.AttackStop_C
// Size: 0x38 (Inherited: 0x38)
struct UAttackStop_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* bpp__MeshComp__pf, struct UAnimSequenceBase* bpp__Animation__pf); // Function At.AttackStop_C.Received_Notify // (Native|Event|Public|BlueprintCallable|Const) // @ game+0x8d0700
};

