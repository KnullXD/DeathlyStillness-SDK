// WidgetBlueprintGeneratedClass Logo.Logo_C
// Size: 0x268 (Inherited: 0x260)
struct ULogo_C : UUserWidget {
	struct UImage* Image_1; // 0x260(0x08)
};

