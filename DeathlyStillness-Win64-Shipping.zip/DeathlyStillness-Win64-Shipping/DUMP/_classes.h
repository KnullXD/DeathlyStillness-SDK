// WidgetBlueprintGeneratedClass . ��钮
// Size: 0x298 (Inherited: 0x260)
struct U ��钮 : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation*   ; // 0x268(0x08)
	struct UButton* Button_132; // 0x270(0x08)
	struct UTextBlock* TextBlock_138; // 0x278(0x08)
	struct FText Name; // 0x280(0x18)

	void BndEvt__Button_131_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function . ��钮.BndEvt__Button_131_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_131_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function . ��钮.BndEvt__Button_131_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_按C(int32_t EntryPoint); // Function . ��钮. xecuteUbergraph_按C // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

