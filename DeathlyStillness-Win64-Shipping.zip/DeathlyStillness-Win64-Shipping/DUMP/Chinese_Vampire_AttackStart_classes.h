// BlueprintGeneratedClass Chinese_Vampire_AttackStart.Chinese_Vampire_AttackStart_C
// Size: 0x38 (Inherited: 0x38)
struct UChinese_Vampire_AttackStart_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function Chinese_Vampire_AttackStart.Chinese_Vampire_AttackStart_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x107f740
};

