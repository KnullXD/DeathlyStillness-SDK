// WidgetBlueprintGeneratedClass KeyBoardShow.KeyBoardShow_C
// Size: 0x290 (Inherited: 0x260)
struct UKeyBoardShow_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* 1; // 0x268(0x08)
	struct UKeyboardLayout_C* KeyboardLayout; // 0x270(0x08)
	struct UTextBlock* TextBlock_93; // 0x278(0x08)
	struct U ��钮*  �� _226; // 0x280(0x08)
	struct APlayer_BP_C* PlayerRef; // 0x288(0x08)

	void Construct(); // Function KeyBoardShow.KeyBoardShow_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void  ��  _1(); // Function KeyBoardShow.KeyBoardShow_C. ��  _1 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_KeyBoardShow(int32_t EntryPoint); // Function KeyBoardShow.KeyBoardShow_C.ExecuteUbergraph_KeyBoardShow // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

