// WidgetBlueprintGeneratedClass AmmoTips.AmmoTips_C
// Size: 0x270 (Inherited: 0x260)
struct UAmmoTips_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_1; // 0x268(0x08)

	void Construct(); // Function AmmoTips.AmmoTips_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_AmmoTips(int32_t EntryPoint); // Function AmmoTips.AmmoTips_C.ExecuteUbergraph_AmmoTips // (Final|UbergraphFunction) // @ game+0x107f740
};

