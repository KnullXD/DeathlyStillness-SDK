// BlueprintGeneratedClass Hit_CameraShake1.Hit_CameraShake1_C
// Size: 0x180 (Inherited: 0x180)
struct UHit_CameraShake1_C : UMatineeCameraShake {
};

