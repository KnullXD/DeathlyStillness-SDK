// WidgetBlueprintGeneratedClass 设置s . ��置滑 
// Size: 0x2c8 (Inherited: 0x260)
struct U ��置滑  : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_52; // 0x268(0x08)
	struct UProgressBar* ProgressBar_102; // 0x270(0x08)
	struct USlider* Slider_101; // 0x278(0x08)
	struct UTextBlock* TextBlock_91; // 0x280(0x08)
	struct UTextBlock* TextBlock_212; // 0x288(0x08)
	struct FText SettingMode; // 0x290(0x18)
	struct USaveSetting_C* SaveSettingRef; // 0x2a8(0x08)
	bool IsClick; // 0x2b0(0x01)
	char pad_2B1[0x3]; // 0x2b1(0x03)
	int32_t  �� ; // 0x2b4(0x04)
	enum class SettingEnum SettingEnum; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	struct UPlayerStateSetting_C* PlayerSetting; // 0x2c0(0x08)

	void BGMSoundSave(); // Function 设置s . ��置滑 .BGMSoundSave // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void MouseYSave(); // Function 设置s . ��置滑 .MouseYSave // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void MouseXSave(); // Function 设置s . ��置滑 .MouseXSave // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��入(); // Function 设置s . ��置滑 . ��入 // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	struct FText GetText_1(); // Function 设置s . ��置滑 .GetText_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	float GetPercent_1(); // Function 设置s . ��置滑 .GetPercent_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x107f740
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function 设置s . ��置滑 .OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function 设置s . ��置滑 .OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x107f740
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Function 设置s . ��置滑 .OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x107f740
	void Reset(); // Function 设置s . ��置滑 .Reset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ndEvt__设置滑块Slot_Slider_100_K2Node_ComponentBoundEvent_1_OnFloatValueChangedEvent__DelegateS(float Value); // Function 设置s . ��置滑 . ndEvt__设置滑块Slot_Slider_100_K2Node_ComponentBoundEvent_1_OnFloatValueChangedEvent__DelegateS // (BlueprintEvent) // @ game+0x107f740
	void Construct(); // Function 设置s . ��置滑 .Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_设置ss(int32_t EntryPoint); // Function 设置s . ��置滑 . xecuteUbergraph_设置ss // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

