// BlueprintGeneratedClass FireShake.FireShake_C
// Size: 0x180 (Inherited: 0x180)
struct UFireShake_C : UMatineeCameraShake {
};

