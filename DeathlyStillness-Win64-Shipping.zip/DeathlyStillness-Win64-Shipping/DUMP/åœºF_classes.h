// BlueprintGeneratedClass 场F. ��景
// Size: 0x238 (Inherited: 0x220)
struct A ��景 : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UAudioComponent* Audio; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)

	void  ��换(struct USoundBase* NewSound); // Function 场F. ��景. ��换 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_场C(int32_t EntryPoint); // Function 场F. ��景. xecuteUbergraph_场C // (Final|UbergraphFunction) // @ game+0x107f740
};

