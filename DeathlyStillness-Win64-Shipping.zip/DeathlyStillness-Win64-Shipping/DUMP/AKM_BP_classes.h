// BlueprintGeneratedClass AKM_BP.AKM_BP_C
// Size: 0x2c4 (Inherited: 0x2c4)
struct AAKM_BP_C : AWeapon_Master_C {
};

