// WidgetBlueprintGeneratedClass Destination_UMG.Destination_UMG_C
// Size: 0x27c (Inherited: 0x260)
struct UDestination_UMG_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_1; // 0x268(0x08)
	struct UTextBlock* TextBlock_65; // 0x270(0x08)
	float Distance; // 0x278(0x04)

	void QuestDistance(struct AActor*  ��, struct FTransform& T, struct AActor*  �� ); // Function Destination_UMG.Destination_UMG_C.QuestDistance // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Destination_UMG(int32_t EntryPoint); // Function Destination_UMG.Destination_UMG_C.ExecuteUbergraph_Destination_UMG // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

