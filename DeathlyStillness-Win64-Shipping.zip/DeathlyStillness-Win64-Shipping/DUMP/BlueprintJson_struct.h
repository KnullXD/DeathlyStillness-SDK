// Enum BlueprintJson.EJsonType
enum class EJsonType : uint8 {
	None = 0,
	Null = 1,
	String = 2,
	Number = 3,
	Boolean = 4,
	Array = 5,
	Object = 6,
	EJsonType_MAX = 7
};

// ScriptStruct BlueprintJson.BlueprintJsonValue
// Size: 0x10 (Inherited: 0x00)
struct FBlueprintJsonValue {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct BlueprintJson.BlueprintJsonObject
// Size: 0x10 (Inherited: 0x00)
struct FBlueprintJsonObject {
	char pad_0[0x10]; // 0x00(0x10)
};

