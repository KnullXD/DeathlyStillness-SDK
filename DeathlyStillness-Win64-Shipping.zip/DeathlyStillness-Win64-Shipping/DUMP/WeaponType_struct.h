// Enum WeaponType.WeaponType
enum class WeaponType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	WeaponType_MAX = 2
};

