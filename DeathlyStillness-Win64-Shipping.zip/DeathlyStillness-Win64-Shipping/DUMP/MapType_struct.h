// Enum MapType.MapType
enum class MapType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	MapType_MAX = 2
};

