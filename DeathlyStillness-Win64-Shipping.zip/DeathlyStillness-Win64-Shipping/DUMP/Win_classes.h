// WidgetBlueprintGeneratedClass Win.Win_C
// Size: 0x2c0 (Inherited: 0x260)
struct UWin_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* 2; // 0x268(0x08)
	struct UWidgetAnimation* 1; // 0x270(0x08)
	struct UWidgetAnimation* Appear; // 0x278(0x08)
	struct UButton* Button; // 0x280(0x08)
	struct UButton* Button_3; // 0x288(0x08)
	struct UImage* Image_463; // 0x290(0x08)
	struct UTextBlock* TextBlock; // 0x298(0x08)
	struct UTextBlock* TextBlock_2; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_3; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_236; // 0x2b0(0x08)
	struct UTextBlock* TextBlock_444; // 0x2b8(0x08)

	void BndEvt__Button_2_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function Win.Win_C.BndEvt__Button_2_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function Win.Win_C.BndEvt__Button_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function Win.Win_C.BndEvt__Button_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_2_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function Win.Win_C.BndEvt__Button_2_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Function Win.Win_C.BndEvt__Button_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_2_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function Win.Win_C.BndEvt__Button_2_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void Construct(); // Function Win.Win_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Win(int32_t EntryPoint); // Function Win.Win_C.ExecuteUbergraph_Win // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

