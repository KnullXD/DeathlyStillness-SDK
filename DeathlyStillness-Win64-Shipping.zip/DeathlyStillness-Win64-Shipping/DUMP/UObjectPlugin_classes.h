// Class UObjectPlugin.MyPluginObject
// Size: 0x38 (Inherited: 0x28)
struct UMyPluginObject : UObject {
	struct FMyPluginStruct MyStruct; // 0x28(0x10)
};

