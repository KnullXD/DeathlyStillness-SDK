// Enum DatasmithCore.EDatasmithPropertyCategory
enum class EDatasmithPropertyCategory : uint8 {
	Undefined = 0,
	Generic = 1,
	RelativeLocation = 2,
	RelativeRotation = 4,
	RelativeScale3D = 8,
	Visibility = 16,
	Material = 32,
	Color = 64,
	Option = 128,
	EDatasmithPropertyCategory_MAX = 129
};

// Enum DatasmithCore.EDatasmithCompletionMode
enum class EDatasmithCompletionMode : uint8 {
	KeepState = 0,
	RestoreState = 1,
	ProjectDefault = 2,
	EDatasmithCompletionMode_MAX = 3
};

// Enum DatasmithCore.EDatasmithActorAttachmentRule
enum class EDatasmithActorAttachmentRule : uint8 {
	KeepRelativeTransform = 0,
	KeepWorldTransform = 1,
	EDatasmithActorAttachmentRule_MAX = 2
};

// Enum DatasmithCore.EDatasmithActorRemovalRule
enum class EDatasmithActorRemovalRule : uint8 {
	RemoveChildren = 0,
	KeepChildrenAndKeepRelativeTransform = 1,
	EDatasmithActorRemovalRule_MAX = 2
};

// Enum DatasmithCore.EDatasmithKeyValuePropertyType
enum class EDatasmithKeyValuePropertyType : uint8 {
	String = 0,
	Color = 1,
	Float = 2,
	Bool = 3,
	Texture = 4,
	Vector = 5,
	Integer = 6,
	EDatasmithKeyValuePropertyType_MAX = 7
};

// Enum DatasmithCore.EDatasmithColorSpace
enum class EDatasmithColorSpace : uint8 {
	Default = 0,
	sRGB = 1,
	Linear = 2,
	EDatasmithColorSpace_MAX = 3
};

// Enum DatasmithCore.EDatasmithTextureFormat
enum class EDatasmithTextureFormat : uint8 {
	PNG = 0,
	JPEG = 1,
	EDatasmithTextureFormat_MAX = 2
};

// Enum DatasmithCore.EDatasmithTextureAddress
enum class EDatasmithTextureAddress : uint8 {
	Wrap = 0,
	Clamp = 1,
	Mirror = 2,
	EDatasmithTextureAddress_MAX = 3
};

// Enum DatasmithCore.EDatasmithTextureFilter
enum class EDatasmithTextureFilter : uint8 {
	Nearest = 0,
	Bilinear = 1,
	Trilinear = 2,
	Default = 3,
	EDatasmithTextureFilter_MAX = 4
};

// Enum DatasmithCore.EDatasmithTextureMode
enum class EDatasmithTextureMode : uint8 {
	Diffuse = 0,
	Specular = 1,
	Normal = 2,
	NormalGreenInv = 3,
	Displace = 4,
	Other = 5,
	Bump = 6,
	Ies = 7,
	EDatasmithTextureMode_MAX = 8
};

// Enum DatasmithCore.EDatasmithLightShape
enum class EDatasmithLightShape : uint8 {
	Rectangle = 0,
	Disc = 1,
	Sphere = 2,
	Cylinder = 3,
	None = 4,
	EDatasmithLightShape_MAX = 5
};

// ScriptStruct DatasmithCore.DatasmithMeshSourceModel
// Size: 0x40 (Inherited: 0x00)
struct FDatasmithMeshSourceModel {
	char pad_0[0x40]; // 0x00(0x40)
};

