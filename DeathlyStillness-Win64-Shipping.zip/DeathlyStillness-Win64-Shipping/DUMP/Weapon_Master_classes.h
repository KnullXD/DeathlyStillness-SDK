// BlueprintGeneratedClass Weapon_Master.Weapon_Master_C
// Size: 0x2c4 (Inherited: 0x220)
struct AWeapon_Master_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UChildActorComponent* BP_Flashlight_Demo; // 0x228(0x08)
	struct USphereComponent*  ��手; // 0x230(0x08)
	struct UArrowComponent* Muzzle; // 0x238(0x08)
	struct UStaticMeshComponent* Medium_Suppressor_01; // 0x240(0x08)
	struct UStaticMeshComponent* Scope; // 0x248(0x08)
	struct UArrowComponent* Arrow; // 0x250(0x08)
	struct USkeletalMeshComponent* SkeletalMesh1; // 0x258(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x260(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x268(0x08)
	float Timeline_0_NewTrack_0_B8A0D7ED4E700FCE1A6C888C9DD6AE58; // 0x270(0x04)
	enum class ETimelineDirection Timeline_0__Direction_B8A0D7ED4E700FCE1A6C888C9DD6AE58; // 0x274(0x01)
	char pad_275[0x3]; // 0x275(0x03)
	struct UTimelineComponent* Timeline_1; // 0x278(0x08)
	float   ; // 0x280(0x04)
	float RecoilPitch; // 0x284(0x04)
	bool RecoilReturnsForFirstShot; // 0x288(0x01)
	char pad_289[0x3]; // 0x289(0x03)
	float RecoilYaw; // 0x28c(0x04)
	struct UAnimSequence* FireAnimaiton; // 0x290(0x08)
	struct AActor* BulletClass; // 0x298(0x08)
	int32_t Bullet_Num; // 0x2a0(0x04)
	struct FName WeaponName; // 0x2a4(0x08)
	int32_t Bullet_ClipNum; // 0x2ac(0x04)
	struct AClip_Master_C* Clip_BP; // 0x2b0(0x08)
	struct APlayer_BP_C* PlayerRef; // 0x2b8(0x08)
	int32_t BulletSave; // 0x2c0(0x04)

	struct FRotator  ��弹(); // Function Weapon_Master.Weapon_Master_C. ��弹 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Timeline_0__FinishedFunc(); // Function Weapon_Master.Weapon_Master_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0x107f740
	void Timeline_0__UpdateFunc(); // Function Weapon_Master.Weapon_Master_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0x107f740
	void ReloadEnd(); // Function Weapon_Master.Weapon_Master_C.ReloadEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReloadStart(); // Function Weapon_Master.Weapon_Master_C.ReloadStart // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReverseRecoil(); // Function Weapon_Master.Weapon_Master_C.ReverseRecoil // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Recoil(); // Function Weapon_Master.Weapon_Master_C.Recoil // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Fire(); // Function Weapon_Master.Weapon_Master_C.Fire // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Shooting(); // Function Weapon_Master.Weapon_Master_C.Shooting // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void StopFire(); // Function Weapon_Master.Weapon_Master_C.StopFire // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveBeginPlay(); // Function Weapon_Master.Weapon_Master_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void ShellCollide(struct FName EventName, float EmitterTime, int32_t ParticleTime, struct FVector Location, struct FVector Velocity, struct FVector Direction, struct FVector Normal, struct FName BoneName, struct UPhysicalMaterial* PhysMat); // Function Weapon_Master.Weapon_Master_C.ShellCollide // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Weapon_Master(int32_t EntryPoint); // Function Weapon_Master.Weapon_Master_C.ExecuteUbergraph_Weapon_Master // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

