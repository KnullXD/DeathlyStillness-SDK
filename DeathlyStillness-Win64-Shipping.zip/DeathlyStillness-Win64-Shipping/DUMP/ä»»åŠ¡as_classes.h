// WidgetBlueprintGeneratedClass 任务as. ��务提 
// Size: 0x288 (Inherited: 0x260)
struct U ��务提  : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* QuestAnim; // 0x268(0x08)
	struct UImage* Image_11; // 0x270(0x08)
	struct UImage* Image_88; // 0x278(0x08)
	struct UTextBlock* TextBlock_650; // 0x280(0x08)

	void  ��新(struct FText InText, struct UTexture2D* Texture); // Function 任务as. ��务提 . ��新 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_任务ss(int32_t EntryPoint); // Function 任务as. ��务提 . xecuteUbergraph_任务ss // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

