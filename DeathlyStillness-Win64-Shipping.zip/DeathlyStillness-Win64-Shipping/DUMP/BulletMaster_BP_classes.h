// BlueprintGeneratedClass BulletMaster_BP.BulletMaster_BP_C
// Size: 0x254 (Inherited: 0x220)
struct ABulletMaster_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UStaticMeshComponent* Sphere1; // 0x228(0x08)
	struct USphereComponent* Sphere; // 0x230(0x08)
	struct UProjectileMovementComponent* ProjectileMovement; // 0x238(0x08)
	struct USoundBase* Sound; // 0x240(0x08)
	struct UInGame_Umg_C* InGameUMG; // 0x248(0x08)
	float  �� ; // 0x250(0x04)

	void HitSurface(struct FHitResult& Hit); // Function BulletMaster_BP.BulletMaster_BP_C.HitSurface // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BulletMaster_BP.BulletMaster_BP_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x107f740
	void ReceiveBeginPlay(); // Function BulletMaster_BP.BulletMaster_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_BulletMaster_BP(int32_t EntryPoint); // Function BulletMaster_BP.BulletMaster_BP_C.ExecuteUbergraph_BulletMaster_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

