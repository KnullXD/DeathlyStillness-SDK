// WidgetBlueprintGeneratedClass PickUpTips.PickUpTips_C
// Size: 0x278 (Inherited: 0x260)
struct UPickUpTips_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_1; // 0x268(0x08)
	struct UImage* Image_2; // 0x270(0x08)

	void Construct(); // Function PickUpTips.PickUpTips_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_PickUpTips(int32_t EntryPoint); // Function PickUpTips.PickUpTips_C.ExecuteUbergraph_PickUpTips // (Final|UbergraphFunction) // @ game+0x107f740
};

