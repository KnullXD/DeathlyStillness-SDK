// BlueprintGeneratedClass Scar_BP.Scar_BP_C
// Size: 0x2c4 (Inherited: 0x2c4)
struct AScar_BP_C : AWeapon_Master_C {
};

