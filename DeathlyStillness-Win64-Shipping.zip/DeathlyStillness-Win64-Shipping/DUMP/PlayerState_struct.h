// Enum PlayerState.PlayerState
enum class PlayerState : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator7 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	PlayerState_MAX = 5
};

