// BlueprintGeneratedClass Location_BP.Location_BP_C
// Size: 0x250 (Inherited: 0x220)
struct ALocation_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UWidgetComponent*  �� ; // 0x228(0x08)
	struct UBoxComponent* Box; // 0x230(0x08)
	struct UDestination_UMG_C* Location_UMG; // 0x238(0x08)
	enum class QuestType QuestType; // 0x240(0x01)
	bool Start; // 0x241(0x01)
	enum class MapType MapType; // 0x242(0x01)
	char pad_243[0x5]; // 0x243(0x05)
	struct UTexture2D* PickupImage; // 0x248(0x08)

	void RenderDeepOpen(); // Function Location_BP.Location_BP_C.RenderDeepOpen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void RenderDeepClose(); // Function Location_BP.Location_BP_C.RenderDeepClose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveTick(float DeltaSeconds); // Function Location_BP.Location_BP_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x107f740
	void  ��建 (); // Function Location_BP.Location_BP_C. ��建  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void BndEvt__Location_BP_Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function Location_BP.Location_BP_C.BndEvt__Location_BP_Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x107f740
	void BndEvt__Location_BP_Box_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function Location_BP.Location_BP_C.BndEvt__Location_BP_Box_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void Pickup(); // Function Location_BP.Location_BP_C.Pickup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveBeginPlay(); // Function Location_BP.Location_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Location_BP(int32_t EntryPoint); // Function Location_BP.Location_BP_C.ExecuteUbergraph_Location_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

