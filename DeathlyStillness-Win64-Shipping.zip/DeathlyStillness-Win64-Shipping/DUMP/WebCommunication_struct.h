// Enum WebCommunication.EHTTPWebComFileUpload
enum class EHTTPWebComFileUpload : uint8 {
	E_gd = 0,
	E_ad = 1,
	E_MAX = 2
};

// Enum WebCommunication.EHTTPWebComFileBytesToFileActionType
enum class EHTTPWebComFileBytesToFileActionType : uint8 {
	E_OVERWRITE = 0,
	E_NOT_OVERWRITE = 1,
	E_MAX = 2
};

// Enum WebCommunication.EHTTPWebComFileDownloadResumeType
enum class EHTTPWebComFileDownloadResumeType : uint8 {
	E_OVERWRITE = 0,
	E_NOT_OVERWRITE = 1,
	E_RESUME = 2,
	E_MAX = 3
};

// Enum WebCommunication.EHTTPWebComFileUploadType
enum class EHTTPWebComFileUploadType : uint8 {
	E_fut_put = 0,
	E_fut_post = 1,
	E_fut_MAX = 2
};

// Enum WebCommunication.EFileFunctionsWebComDirectoryType
enum class EFileFunctionsWebComDirectoryType : uint8 {
	E_gd = 0,
	E_ad = 1,
	E_MAX = 2
};

// Enum WebCommunication.EHTTPWebComRequestType
enum class EHTTPWebComRequestType : uint8 {
	GET = 0,
	GETLowRamDownload = 1,
	PUT = 2,
	POST = 3,
	POST_UPLOAD = 4,
	INDIVIDUAL = 5,
	EHTTPWebComRequestType_MAX = 6
};

// ScriptStruct WebCommunication.httpRequest
// Size: 0x100 (Inherited: 0x00)
struct FhttpRequest {
	char pad_0[0x100]; // 0x00(0x100)
};

