// BlueprintGeneratedClass 丧尸ec. ��尸生 
// Size: 0x248 (Inherited: 0x220)
struct A ��尸生  : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
	int32_t  ��成 ; // 0x230(0x04)
	char pad_234[0x4]; // 0x234(0x04)
	struct TArray<struct AActor*>  ��  ; // 0x238(0x10)

	void  �� (); // Function 丧尸ec. ��尸生 . ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_丧尸ss(int32_t EntryPoint); // Function 丧尸ec. ��尸生 . xecuteUbergraph_丧尸ss // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

