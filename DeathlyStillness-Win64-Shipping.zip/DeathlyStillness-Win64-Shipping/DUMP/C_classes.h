// DynamicClass C.ChasoPlayer_C
// Size: 0x108 (Inherited: 0xa8)
struct UChasoPlayer_C : UBTTask_BlueprintBase {
	enum class EPathFollowingResult K2Node_CustomEvent_MovementResult_2; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0xac(0x10)
	enum class EPathFollowingResult K2Node_CustomEvent_MovementResult; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0xc0(0x10)
	enum class EPathFollowingResult ___byte_Variable; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)
	struct AAIController* K2Node_Event_OwnerController; // 0xd8(0x08)
	struct APawn* K2Node_Event_ControlledPawn; // 0xe0(0x08)
	struct AZombie_AIController_C* K2Node_DynamicCast_AsZombie_AIController; // 0xe8(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct UAIAsyncTaskBlueprintProxy* CallFunc_CreateMoveToProxyObject_ReturnValue; // 0xf8(0x08)
	bool CallFunc_IsValid_ReturnValue; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)

	void ReceiveExecuteAI(struct AAIController* bpp__OwnerController__pf, struct APawn* bpp__ControlledPawn__pf); // Function C.ChasoPlayer_C.ReceiveExecuteAI // (Native|Event|Public) // @ game+0x8d0490
	void OnSuccess_D71D87724551652EE8309BBB469345F1(enum class EPathFollowingResult bpp__MovementResult__pf); // Function C.ChasoPlayer_C.OnSuccess_D71D87724551652EE8309BBB469345F1 // (Native|Public|BlueprintCallable) // @ game+0x8d03f0
	void OnFail_D71D87724551652EE8309BBB469345F1(enum class EPathFollowingResult bpp__MovementResult__pf); // Function C.ChasoPlayer_C.OnFail_D71D87724551652EE8309BBB469345F1 // (Native|Public|BlueprintCallable) // @ game+0x8d0370
	void OAISimpleDelegate__DelegateSignature(enum class EPathFollowingResult bpp__MovementResult__pf); // DelegateFunction C.ChasoPlayer_C.OAISimpleDelegate__DelegateSignature // (Public|Delegate) // @ game+0x107f740
};

