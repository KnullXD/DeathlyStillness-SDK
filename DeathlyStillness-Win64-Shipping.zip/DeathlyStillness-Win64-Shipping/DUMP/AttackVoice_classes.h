// BlueprintGeneratedClass AttackVoice.AttackVoice_C
// Size: 0x3c (Inherited: 0x38)
struct UAttackVoice_C : UAnimNotify {
	float Scale; // 0x38(0x04)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AttackVoice.AttackVoice_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x107f740
};

