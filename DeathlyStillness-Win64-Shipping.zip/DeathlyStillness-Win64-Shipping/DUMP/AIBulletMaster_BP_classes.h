// BlueprintGeneratedClass AIBulletMaster_BP.AIBulletMaster_BP_C
// Size: 0x248 (Inherited: 0x220)
struct AAIBulletMaster_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USphereComponent* Sphere; // 0x228(0x08)
	struct UProjectileMovementComponent* ProjectileMovement; // 0x230(0x08)
	struct UStaticMeshComponent* Sphere1; // 0x238(0x08)
	struct USoundBase* Sound; // 0x240(0x08)

	void ReceiveBeginPlay(); // Function AIBulletMaster_BP.AIBulletMaster_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_AIBulletMaster_BP(int32_t EntryPoint); // Function AIBulletMaster_BP.AIBulletMaster_BP_C.ExecuteUbergraph_AIBulletMaster_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

