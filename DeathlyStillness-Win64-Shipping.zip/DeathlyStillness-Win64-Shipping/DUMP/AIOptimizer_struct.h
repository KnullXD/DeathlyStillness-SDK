// Enum AIOptimizer.EAIOStartSpawningMethod
enum class EAIOStartSpawningMethod : uint8 {
	None = 0,
	SpawnOnGameStart = 1,
	SpawnOnRadius = 2,
	SpawnOnRegion = 3,
	EAIOStartSpawningMethod_MAX = 4
};

// Enum AIOptimizer.EAIOSpawnPointsProjectionMethod
enum class EAIOSpawnPointsProjectionMethod : uint8 {
	None = 0,
	Geometry = 1,
	Navigation = 2,
	EAIOSpawnPointsProjectionMethod_MAX = 3
};

// Enum AIOptimizer.EAIORespawnMethod
enum class EAIORespawnMethod : uint8 {
	Undefined = 0,
	AllAtOnce = 1,
	EachIndividually = 2,
	EAIORespawnMethod_MAX = 3
};

// Enum AIOptimizer.EAIOSelectSpawnPointsMethod
enum class EAIOSelectSpawnPointsMethod : uint8 {
	UseRandomPoints = 0,
	UseSpecifiedSpawnPoints = 1,
	EAIOSelectSpawnPointsMethod_MAX = 2
};

// Enum AIOptimizer.EAIODebugGroup
enum class EAIODebugGroup : uint8 {
	Undefined = 0,
	Spawned = 1,
	Despawned = 2,
	PendingSpawn = 3,
	PendingDespawn = 4,
	SpawnedClose = 5,
	SpawnedMedium = 6,
	SpawnedFar = 7,
	NotUpdated = 8,
	EAIODebugGroup_MAX = 9
};

// Enum AIOptimizer.EAIOFeaturesFlags
enum class EAIOFeaturesFlags : uint8 {
	AIBrain = 0,
	MovementComponent = 1,
	Visibility = 2,
	Collision = 3,
	Animations = 4,
	ActorTick = 5,
	Shadows = 6,
	EAIOFeaturesFlags_MAX = 7
};

// Enum AIOptimizer.EDespawnMethod
enum class EDespawnMethod : uint8 {
	UseQueue = 0,
	Immediately = 1,
	EDespawnMethod_MAX = 2
};

// ScriptStruct AIOptimizer.AIOSpawnPoint
// Size: 0x30 (Inherited: 0x00)
struct FAIOSpawnPoint {
	struct FTransform Transform; // 0x00(0x30)
};

// ScriptStruct AIOptimizer.AIOPendingRespawnGroup
// Size: 0x0c (Inherited: 0x00)
struct FAIOPendingRespawnGroup {
	float SpawnGameTime; // 0x00(0x04)
	struct FAIOPendingSpawnGroup SpawnGroup; // 0x04(0x08)
};

// ScriptStruct AIOptimizer.AIOPendingSpawnGroup
// Size: 0x08 (Inherited: 0x00)
struct FAIOPendingSpawnGroup {
	int32_t SpawnedAmount; // 0x00(0x04)
	int32_t TotalAmountToSpawn; // 0x04(0x04)
};

// ScriptStruct AIOptimizer.AIODebugSubjectData
// Size: 0x28 (Inherited: 0x00)
struct FAIODebugSubjectData {
	int32_t Layer; // 0x00(0x04)
	struct FVector SubjectLocation; // 0x04(0x0c)
	struct FVector InvokerLocation; // 0x10(0x0c)
	char bIsSpawned : 1; // 0x1c(0x01)
	char bIsPending : 1; // 0x1c(0x01)
	char bNotUpdated : 1; // 0x1c(0x01)
	char bIsSeen : 1; // 0x1c(0x01)
	char pad_1C_4 : 4; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	float DistanceToInvoker; // 0x20(0x04)
	float DespawnRadius; // 0x24(0x04)
};

// ScriptStruct AIOptimizer.AIOptimizationLayer
// Size: 0x08 (Inherited: 0x00)
struct FAIOptimizationLayer {
	float LayerRadius; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
};

// ScriptStruct AIOptimizer.AIOInvoker
// Size: 0x08 (Inherited: 0x00)
struct FAIOInvoker {
	struct UAIOInvokerComponent* Component; // 0x00(0x08)
};

// ScriptStruct AIOptimizer.AIOSubject
// Size: 0x10 (Inherited: 0x00)
struct FAIOSubject {
	struct UAIOSubjectComponent* Component; // 0x00(0x08)
	int32_t Priority; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct AIOptimizer.AIODespawnedSubject
// Size: 0x60 (Inherited: 0x00)
struct FAIODespawnedSubject {
	struct FTransform Transform; // 0x00(0x30)
	struct AActor* Class; // 0x30(0x08)
	float SpawnRadiusSquared; // 0x38(0x04)
	char Priority; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct UAIOData_Base* Data; // 0x40(0x08)
	struct FAIOSubjectHandle Handle; // 0x48(0x04)
	char bIsForcedToSpawn : 1; // 0x4c(0x01)
	char bCanBeRespawnedOnlyByHandle : 1; // 0x4c(0x01)
	char pad_4C_2 : 6; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	struct AActor* Spawner; // 0x50(0x08)
	char pad_58[0x8]; // 0x58(0x08)
};

// ScriptStruct AIOptimizer.AIOSubjectHandle
// Size: 0x04 (Inherited: 0x00)
struct FAIOSubjectHandle {
	int32_t HandleId; // 0x00(0x04)
};

