// BlueprintGeneratedClass SavePlayerState_BP.SavePlayerState_BP_C
// Size: 0x48 (Inherited: 0x28)
struct USavePlayerState_BP_C : USaveGame {
	struct USkeletalMesh* SkeletalMesh; // 0x28(0x08)
	enum class WeaponType WeaponType; // 0x30(0x01)
	enum class CharacterModel CharacterModel; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
	struct USkeletalMesh*  ��  ; // 0x38(0x08)
	struct USkeletalMesh*  ��  ; // 0x40(0x08)
};

