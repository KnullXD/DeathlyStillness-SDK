// BlueprintGeneratedClass Player_BP.Player_BP_C
// Size: 0x720 (Inherited: 0x4c0)
struct APlayer_BP_C : ACharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct USkeletalMeshComponent* SK_Backpack_A; // 0x4c8(0x08)
	struct USkeletalMeshComponent* SK_HairStyle_C; // 0x4d0(0x08)
	struct USpringArmComponent* SpringArm; // 0x4d8(0x08)
	struct UAIOInvokerComponent* AIOInvoker; // 0x4e0(0x08)
	struct UArrowComponent* Arrow1; // 0x4e8(0x08)
	struct UArrowComponent* Foot_L; // 0x4f0(0x08)
	struct UArrowComponent* Foot_R; // 0x4f8(0x08)
	struct UCameraComponent* Camera1; // 0x500(0x08)
	struct USpringArmComponent* DeadSpringArm; // 0x508(0x08)
	struct UCameraComponent* Camera; // 0x510(0x08)
	float ____3______0_923112A7416F84A871D034A5B5554652; // 0x518(0x04)
	enum class ETimelineDirection ____3__Direction_923112A7416F84A871D034A5B5554652; // 0x51c(0x01)
	char pad_51D[0x3]; // 0x51d(0x03)
	struct UTimelineComponent*  ��_4; // 0x520(0x08)
	float ____2_NewTrack_0_95A435B14F0AB199B170D8870A2EF353; // 0x528(0x04)
	enum class ETimelineDirection ____2__Direction_95A435B14F0AB199B170D8870A2EF353; // 0x52c(0x01)
	char pad_52D[0x3]; // 0x52d(0x03)
	struct UTimelineComponent*  ��_3; // 0x530(0x08)
	float ____1_NewTrack_0_CC017F63449C12F4E4D38182FC67D3CA; // 0x538(0x04)
	enum class ETimelineDirection ____1__Direction_CC017F63449C12F4E4D38182FC67D3CA; // 0x53c(0x01)
	char pad_53D[0x3]; // 0x53d(0x03)
	struct UTimelineComponent*  ��_2; // 0x540(0x08)
	float ____0______0_AAD5C963468689DBD2F8E3A8EFD8FD12; // 0x548(0x04)
	enum class ETimelineDirection ____0__Direction_AAD5C963468689DBD2F8E3A8EFD8FD12; // 0x54c(0x01)
	char pad_54D[0x3]; // 0x54d(0x03)
	struct UTimelineComponent*  ��_1; // 0x550(0x08)
	float Timeline_2_NewTrack_0_F33D607F4B708783A339AE84DB0C3916; // 0x558(0x04)
	enum class ETimelineDirection Timeline_2__Direction_F33D607F4B708783A339AE84DB0C3916; // 0x55c(0x01)
	char pad_55D[0x3]; // 0x55d(0x03)
	struct UTimelineComponent* Timeline_3; // 0x560(0x08)
	float Timeline_1_NewTrack_0_772BFAE24A784F386485D1BDBA599C3C; // 0x568(0x04)
	enum class ETimelineDirection Timeline_1__Direction_772BFAE24A784F386485D1BDBA599C3C; // 0x56c(0x01)
	char pad_56D[0x3]; // 0x56d(0x03)
	struct UTimelineComponent* Timeline_2; // 0x570(0x08)
	float Timeline_0_NewTrack_0_09057ECC4237004FF562A88E0003CBFB; // 0x578(0x04)
	enum class ETimelineDirection Timeline_0__Direction_09057ECC4237004FF562A88E0003CBFB; // 0x57c(0x01)
	char pad_57D[0x3]; // 0x57d(0x03)
	struct UTimelineComponent* Timeline_1; // 0x580(0x08)
	bool Run?; // 0x588(0x01)
	bool Aiming; // 0x589(0x01)
	char pad_58A[0x6]; // 0x58a(0x06)
	struct AWeapon_Master_C* Weapon; // 0x590(0x08)
	float Health; // 0x598(0x04)
	bool Dead; // 0x59c(0x01)
	bool RunStop; // 0x59d(0x01)
	char pad_59E[0x2]; // 0x59e(0x02)
	struct TArray<struct UAnimMontage*> RunStopAnim; // 0x5a0(0x10)
	struct TArray<struct UAnimMontage*> WalkStopAnim; // 0x5b0(0x10)
	bool CanStop?; // 0x5c0(0x01)
	bool MontagePlaying; // 0x5c1(0x01)
	char pad_5C2[0x6]; // 0x5c2(0x06)
	struct UAnimMontage* RunStopAnim_1; // 0x5c8(0x08)
	float MoveForward; // 0x5d0(0x04)
	float MoveRight; // 0x5d4(0x04)
	struct UPlayer_Anim_C* PlayerAnimRef; // 0x5d8(0x08)
	struct UInGame_Umg_C* InGameUMG; // 0x5e0(0x08)
	bool CanControl; // 0x5e8(0x01)
	char pad_5E9[0x7]; // 0x5e9(0x07)
	struct TArray<struct UAnimMontage*> HitAnim; // 0x5f0(0x10)
	bool CanMelee?; // 0x600(0x01)
	bool MeleeState?; // 0x601(0x01)
	bool DamageEfffect; // 0x602(0x01)
	char pad_603[0x1]; // 0x603(0x01)
	float Health_Save; // 0x604(0x04)
	float HeadBobScale; // 0x608(0x04)
	bool IsReload?; // 0x60c(0x01)
	enum class PlayerState PlayerStateEnum; // 0x60d(0x01)
	bool IsRifleState?; // 0x60e(0x01)
	char pad_60F[0x1]; // 0x60f(0x01)
	float Speed; // 0x610(0x04)
	char pad_614[0x4]; // 0x614(0x04)
	struct TArray<struct UAnimMontage*> RifleRunStopAnim; // 0x618(0x10)
	struct TArray<struct UAnimMontage*> RifleWalkStopAnim; // 0x628(0x10)
	struct TArray<struct AActor*> HitZombieRef; // 0x638(0x10)
	struct TArray<struct UAnimMontage*> MeleeAnim; // 0x648(0x10)
	struct FName StartBone; // 0x658(0x08)
	struct FName EndBone; // 0x660(0x08)
	int32_t  ��战绝; // 0x668(0x04)
	char pad_66C[0x4]; // 0x66c(0x04)
	struct TArray<struct UAnimMontage*> MeleeAnim_1; // 0x670(0x10)
	float SpreadCurrent; // 0x680(0x04)
	float Spread Min; // 0x684(0x04)
	float SpreadMax; // 0x688(0x04)
	float Delta Seconds; // 0x68c(0x04)
	float Spread Decrease Speed; // 0x690(0x04)
	bool Walk?; // 0x694(0x01)
	bool Relaxed; // 0x695(0x01)
	char pad_696[0x2]; // 0x696(0x02)
	struct AActor* NearActor; // 0x698(0x08)
	bool  ��  ; // 0x6a0(0x01)
	char pad_6A1[0x3]; // 0x6a1(0x03)
	int32_t  ��取 ; // 0x6a4(0x04)
	struct U ��停* PauseUMG; // 0x6a8(0x08)
	bool CanJump?; // 0x6b0(0x01)
	char pad_6B1[0x7]; // 0x6b1(0x07)
	struct USaveSetting_C* SaveSettingRef; // 0x6b8(0x08)
	bool IsPause; // 0x6c0(0x01)
	bool IsViewKeyTip; // 0x6c1(0x01)
	char pad_6C2[0x2]; // 0x6c2(0x02)
	int32_t  ��招; // 0x6c4(0x04)
	float FOV; // 0x6c8(0x04)
	float  ��标; // 0x6cc(0x04)
	float  ��  ; // 0x6d0(0x04)
	bool  ��  ; // 0x6d4(0x01)
	char pad_6D5[0x3]; // 0x6d5(0x03)
	struct USoundBase* DamageSound; // 0x6d8(0x08)
	struct USoundBase* JumpSound; // 0x6e0(0x08)
	struct USoundBase* AttackSound; // 0x6e8(0x08)
	float  ��标; // 0x6f0(0x04)
	struct FVector WeaponScale; // 0x6f4(0x0c)
	float FocalLocation; // 0x700(0x04)
	float SpringSocketZ; // 0x704(0x04)
	float SpringSocketY; // 0x708(0x04)
	bool  ��否自; // 0x70c(0x01)
	bool  ��闭; // 0x70d(0x01)
	char pad_70E[0x2]; // 0x70e(0x02)
	struct TArray<struct UAnimMontage*> DeadMontage; // 0x710(0x10)

	void Rotate to Control Rotation(float InterpSpeed); // Function Player_BP.Player_BP_C.Rotate to Control Rotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Increase Spread(float Increase Spread); // Function Player_BP.Player_BP_C.Increase Spread // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void DecreaseSpread(float DecreaseSpread); // Function Player_BP.Player_BP_C.DecreaseSpread // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��(struct USceneComponent* Target, struct FVector& Location); // Function Player_BP.Player_BP_C. �� // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	float  ��色(); // Function Player_BP.Player_BP_C. ��色 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void UserConstructionScript(); // Function Player_BP.Player_BP_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��间轴_3__Finish(); // Function Player_BP.Player_BP_C. ��间轴_3__Finish // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_3__Upda(); // Function Player_BP.Player_BP_C. ��间轴_3__Upda // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_1__Finish(); // Function Player_BP.Player_BP_C. ��间轴_1__Finish // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_1__Upda(); // Function Player_BP.Player_BP_C. ��间轴_1__Upda // (BlueprintEvent) // @ game+0x107f740
	void Timeline_1__FinishedFunc(); // Function Player_BP.Player_BP_C.Timeline_1__FinishedFunc // (BlueprintEvent) // @ game+0x107f740
	void Timeline_1__UpdateFunc(); // Function Player_BP.Player_BP_C.Timeline_1__UpdateFunc // (BlueprintEvent) // @ game+0x107f740
	void Timeline_2__FinishedFunc(); // Function Player_BP.Player_BP_C.Timeline_2__FinishedFunc // (BlueprintEvent) // @ game+0x107f740
	void Timeline_2__UpdateFunc(); // Function Player_BP.Player_BP_C.Timeline_2__UpdateFunc // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_2__Finish(); // Function Player_BP.Player_BP_C. ��间轴_2__Finish // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_2__Upda(); // Function Player_BP.Player_BP_C. ��间轴_2__Upda // (BlueprintEvent) // @ game+0x107f740
	void Timeline_0__FinishedFunc(); // Function Player_BP.Player_BP_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0x107f740
	void Timeline_0__UpdateFunc(); // Function Player_BP.Player_BP_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_0__Finish(); // Function Player_BP.Player_BP_C. ��间轴_0__Finish // (BlueprintEvent) // @ game+0x107f740
	void  ��间轴_0__Upda(); // Function Player_BP.Player_BP_C. ��间轴_0__Upda // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_Tab_K2Node_InputKeyEvent_16(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_Tab_K2Node_InputKeyEvent_16 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_Q_K2Node_InputKeyEvent_15(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_Q_K2Node_InputKeyEvent_15 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_E_K2Node_InputKeyEvent_14(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_E_K2Node_InputKeyEvent_14 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_Escape_K2Node_InputKeyEvent_13(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_Escape_K2Node_InputKeyEvent_13 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_F_K2Node_InputKeyEvent_12(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_F_K2Node_InputKeyEvent_12 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_R_K2Node_InputKeyEvent_11(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_R_K2Node_InputKeyEvent_11 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_T_K2Node_InputKeyEvent_10(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_T_K2Node_InputKeyEvent_10 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_V_K2Node_InputKeyEvent_9(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_V_K2Node_InputKeyEvent_9 // (BlueprintEvent) // @ game+0x107f740
	void Brake_K2Node_InputActionEvent_2(struct FKey Key); // Function Player_BP.Player_BP_C.Brake_K2Node_InputActionEvent_2 // (BlueprintEvent) // @ game+0x107f740
	void Brake_K2Node_InputActionEvent_1(struct FKey Key); // Function Player_BP.Player_BP_C.Brake_K2Node_InputActionEvent_1 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_8(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_8 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_7(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_7 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_RightMouseButton_K2Node_InputKeyEvent_6(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_RightMouseButton_K2Node_InputKeyEvent_6 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_RightMouseButton_K2Node_InputKeyEvent_5(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_RightMouseButton_K2Node_InputKeyEvent_5 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_LeftShift_K2Node_InputKeyEvent_4(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_LeftShift_K2Node_InputKeyEvent_4 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_LeftShift_K2Node_InputKeyEvent_3(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_LeftShift_K2Node_InputKeyEvent_3 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_LeftControl_K2Node_InputKeyEvent_2(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_LeftControl_K2Node_InputKeyEvent_2 // (BlueprintEvent) // @ game+0x107f740
	void InpActEvt_LeftControl_K2Node_InputKeyEvent_1(struct FKey Key); // Function Player_BP.Player_BP_C.InpActEvt_LeftControl_K2Node_InputKeyEvent_1 // (BlueprintEvent) // @ game+0x107f740
	void  �� (float B); // Function Player_BP.Player_BP_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void PickUpOutline(); // Function Player_BP.Player_BP_C.PickUpOutline // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��取成 (); // Function Player_BP.Player_BP_C. ��取成  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��装替 (enum class CharacterModel  �� , struct USkeletalMesh*  �� , struct USkeletalMesh*  ��  , struct USkeletalMesh*  ��  ); // Function Player_BP.Player_BP_C. ��装替  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��动 (); // Function Player_BP.Player_BP_C. ��动  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function Player_BP.Player_BP_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function Player_BP.Player_BP_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function Player_BP.Player_BP_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  �� (); // Function Player_BP.Player_BP_C. ��  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��放(); // Function Player_BP.Player_BP_C. ��放 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��放(); // Function Player_BP.Player_BP_C. ��放 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void LeftFoot(); // Function Player_BP.Player_BP_C.LeftFoot // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void RightFoot(); // Function Player_BP.Player_BP_C.RightFoot // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function Player_BP.Player_BP_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x107f740
	void BloodEffcet Disappear(); // Function Player_BP.Player_BP_C.BloodEffcet Disappear // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��制(); // Function Player_BP.Player_BP_C. ��制 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void StartFire(); // Function Player_BP.Player_BP_C.StartFire // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void StopFire(); // Function Player_BP.Player_BP_C.StopFire // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void StopAiming(); // Function Player_BP.Player_BP_C.StopAiming // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1(float AxisValue); // Function Player_BP.Player_BP_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1 // (BlueprintEvent) // @ game+0x107f740
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2(float AxisValue); // Function Player_BP.Player_BP_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2 // (BlueprintEvent) // @ game+0x107f740
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_3(float AxisValue); // Function Player_BP.Player_BP_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_3 // (BlueprintEvent) // @ game+0x107f740
	void InpAxisEvt_LookUp_K2Node_InputAxisEvent_4(float AxisValue); // Function Player_BP.Player_BP_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_4 // (BlueprintEvent) // @ game+0x107f740
	void ReceiveBeginPlay(); // Function Player_BP.Player_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void ReceiveTick(float DeltaSeconds); // Function Player_BP.Player_BP_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Player_BP(int32_t EntryPoint); // Function Player_BP.Player_BP_C.ExecuteUbergraph_Player_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

