// Class NetCore.NetAnalyticsAggregatorConfig
// Size: 0x38 (Inherited: 0x28)
struct UNetAnalyticsAggregatorConfig : UObject {
	struct TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData; // 0x28(0x10)
};

