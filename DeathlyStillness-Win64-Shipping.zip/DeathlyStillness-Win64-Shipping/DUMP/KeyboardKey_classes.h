// WidgetBlueprintGeneratedClass KeyboardKey.KeyboardKey_C
// Size: 0x2a8 (Inherited: 0x260)
struct UKeyboardKey_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCanvasPanel* CanvasPanel_1; // 0x268(0x08)
	struct UImage* Image; // 0x270(0x08)
	struct UImage* Image_73; // 0x278(0x08)
	struct UTexture2D* KeyTexture; // 0x280(0x08)
	struct FVector2D KeySize; // 0x288(0x08)
	struct FLinearColor Specified Color; // 0x290(0x10)
	struct UKeyBoardShow_C* KeyBoardShow; // 0x2a0(0x08)

	void PreConstruct(bool IsDesignTime); // Function KeyboardKey.KeyboardKey_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_KeyboardKey(int32_t EntryPoint); // Function KeyboardKey.KeyboardKey_C.ExecuteUbergraph_KeyboardKey // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

