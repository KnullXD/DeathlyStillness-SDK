// BlueprintGeneratedClass Melee1.Melee1_C
// Size: 0x3c (Inherited: 0x38)
struct UMelee1_C : UAnimNotify {
	float Scale; // 0x38(0x04)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function Melee1.Melee1_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x107f740
};

