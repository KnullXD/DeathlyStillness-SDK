// Enum CharacterModel.CharacterModel
enum class CharacterModel : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator5 = 3,
	NewEnumerator8 = 4,
	CharacterModel_MAX = 5
};

