// WidgetBlueprintGeneratedClass 设la. ��置U
// Size: 0x310 (Inherited: 0x260)
struct U ��置U : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* 3; // 0x268(0x08)
	struct UWidgetAnimation* 1; // 0x270(0x08)
	struct UButton* Button_105; // 0x278(0x08)
	struct UImage* Image_92; // 0x280(0x08)
	struct UImage* Image_283; // 0x288(0x08)
	struct UTextBlock* TextBlock_176; // 0x290(0x08)
	struct UTextBlock* TextBlock_736; // 0x298(0x08)
	struct U ��置SlotU*  ��置Slo; // 0x2a0(0x08)
	struct U ��置SlotU*  ��置Slo_2; // 0x2a8(0x08)
	struct U ��置SlotU*  ��置Slo_3; // 0x2b0(0x08)
	struct U ��置SlotU*  ��置Slo_4; // 0x2b8(0x08)
	struct U ��置SlotU*  ��置Slo_5; // 0x2c0(0x08)
	struct U ��置SlotU*  ��置Slo_6; // 0x2c8(0x08)
	struct U ��置SlotU*  ��置Slo_7; // 0x2d0(0x08)
	struct U ��置SlotU*  ��置Slo_8; // 0x2d8(0x08)
	struct U ��置SlotU*  ��置Slo_9; // 0x2e0(0x08)
	struct U ��置SlotU*  ��置Slo_10; // 0x2e8(0x08)
	struct UScrollBox*  �� ; // 0x2f0(0x08)
	struct U ��置滑 *  ��置  ; // 0x2f8(0x08)
	struct U ��置滑 *  ��置  _2; // 0x300(0x08)
	struct U ��置滑 *  ��置  _3; // 0x308(0x08)

	void Construct(); // Function 设la. ��置U.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_104_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function 设la. ��置U.BndEvt__Button_104_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BndEvt__Button_104_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function 设la. ��置U.BndEvt__Button_104_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x107f740
	void BGVisibility(enum class EUMGSequencePlayMode PlayMode); // Function 设la. ��置U.BGVisibility // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  xecuteUbergraph_设Cl(int32_t EntryPoint); // Function 设la. ��置U. xecuteUbergraph_设Cl // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

