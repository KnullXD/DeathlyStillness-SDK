// DynamicClass Zombie_AIController.Zombie_AIController_C
// Size: 0x3d8 (Inherited: 0x328)
struct AZombie_AIController_C : AAIController {
	struct UAIPerceptionComponent* AIPerception; // 0x328(0x08)
	struct APawn* ZombieRef; // 0x330(0x08)
	struct FVector  ��后看; // 0x338(0x0c)
	char pad_344[0x4]; // 0x344(0x04)
	struct ACharacter* PlayerRef; // 0x348(0x08)
	struct AActor* K2Node_ComponentBoundEvent_Actor; // 0x350(0x08)
	struct FAIStimulus K2Node_ComponentBoundEvent_Stimulus; // 0x358(0x3c)
	char pad_394[0x4]; // 0x394(0x04)
	struct ACharacter* K2Node_DynamicCast_AsPlayer_BP; // 0x398(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x3a0(0x01)
	char pad_3A1[0x3]; // 0x3a1(0x03)
	struct FVector CallFunc_K2_GetRandomReachablePointInRadius_RandomLocation; // 0x3a4(0x0c)
	struct APawn* K2Node_Event_PossessedPawn; // 0x3b0(0x08)
	bool ___bool_Has_Been_Initd_Variable; // 0x3b8(0x01)
	bool ___bool_IsClosed_Variable; // 0x3b9(0x01)
	char pad_3BA[0x6]; // 0x3ba(0x06)
	struct TArray<struct ACharacter*> CallFunc_GetAllActorsOfClass_OutActors; // 0x3c0(0x10)
	struct ACharacter* CallFunc_Array_Get_Item; // 0x3d0(0x08)

	void Reset(); // Function Zombie_AIController.Zombie_AIController_C.Reset // (Native|Public|BlueprintCallable) // @ game+0x8d07d0
	void ReceivePossess(struct APawn* bpp__PossessedPawn__pf); // Function Zombie_AIController.Zombie_AIController_C.ReceivePossess // (Native|Event|Public) // @ game+0x8d0560
	void ReceiveBeginPlay(); // Function Zombie_AIController.Zombie_AIController_C.ReceiveBeginPlay // (Native|Event|Public) // @ game+0x8d0470
	void BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature(struct AActor* bpp__Actor__pf, struct FAIStimulus bpp__Stimulus__pf); // Function Zombie_AIController.Zombie_AIController_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature // (Native|Public) // @ game+0x8d01e0
};

