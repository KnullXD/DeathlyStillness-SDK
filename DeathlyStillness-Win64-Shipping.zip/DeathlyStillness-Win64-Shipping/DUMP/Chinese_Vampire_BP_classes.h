// BlueprintGeneratedClass Chinese_Vampire_BP.Chinese_Vampire_BP_C
// Size: 0x589 (Inherited: 0x4c0)
struct AChinese_Vampire_BP_C : ACharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct UPointLightComponent* PointLight; // 0x4c8(0x08)
	struct UArrowComponent* LeftFoot; // 0x4d0(0x08)
	struct UArrowComponent* RightFoot; // 0x4d8(0x08)
	float Health; // 0x4e0(0x04)
	bool Dead; // 0x4e4(0x01)
	char pad_4E5[0x3]; // 0x4e5(0x03)
	struct FVector PlayerLoc; // 0x4e8(0x0c)
	char pad_4F4[0x4]; // 0x4f4(0x04)
	struct APlayer_BP_C* PlayerRef; // 0x4f8(0x08)
	struct FVector chaseLocation; // 0x500(0x0c)
	bool CanScream?; // 0x50c(0x01)
	bool Scream?; // 0x50d(0x01)
	char pad_50E[0x2]; // 0x50e(0x02)
	struct TArray<struct USkeletalMesh*> ZombieClass; // 0x510(0x10)
	struct TArray<struct UAnimMontage*> Idle; // 0x520(0x10)
	struct UAnimMontage* PlayIdle; // 0x530(0x08)
	struct UAudioComponent* Aggressive; // 0x538(0x08)
	struct TArray<struct UAnimMontage*> Hit; // 0x540(0x10)
	bool MeleeByPlayer?; // 0x550(0x01)
	bool AttackStart; // 0x551(0x01)
	bool  ��否; // 0x552(0x01)
	char pad_553[0x5]; // 0x553(0x05)
	struct AActor* HitPlayer; // 0x558(0x08)
	struct FName  ��击  ; // 0x560(0x08)
	struct FName  ��击  ; // 0x568(0x08)
	float In Play Rate; // 0x570(0x04)
	char pad_574[0x4]; // 0x574(0x04)
	struct TArray<struct UAnimMontage*> AttackAnim; // 0x578(0x10)
	bool  ��否 ; // 0x588(0x01)

	void  ��  (struct USceneComponent*   ); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C. ��   // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��改  (bool Orient Rotation to Movement, bool Use Controller Rotation Yaw); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C. ��改   // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void OnFail_206D8F7C4CA4F14CAFB01288298C9602(enum class EPathFollowingResult MovementResult); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnFail_206D8F7C4CA4F14CAFB01288298C9602 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void OnSuccess_206D8F7C4CA4F14CAFB01288298C9602(enum class EPathFollowingResult MovementResult); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnSuccess_206D8F7C4CA4F14CAFB01288298C9602 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void OnFail_E471E93B4A7423F2351F7EAE133F7D0C(enum class EPathFollowingResult MovementResult); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnFail_E471E93B4A7423F2351F7EAE133F7D0C // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void OnSuccess_E471E93B4A7423F2351F7EAE133F7D0C(enum class EPathFollowingResult MovementResult); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.OnSuccess_E471E93B4A7423F2351F7EAE133F7D0C // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Reset(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.Reset // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��尸(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C. ��尸 // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveTick(float DeltaSeconds); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x107f740
	void ChangeLightColor(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ChangeLightColor // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void leftFootSound(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.leftFootSound // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void RightFootSound(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.RightFootSound // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x107f740
	void MeleeByPlayer(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.MeleeByPlayer // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void   (); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.   // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void  ��闭 (); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C. ��闭  // (BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void ReceiveBeginPlay(); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x107f740
	void ExecuteUbergraph_Chinese_Vampire_BP(int32_t EntryPoint); // Function Chinese_Vampire_BP.Chinese_Vampire_BP_C.ExecuteUbergraph_Chinese_Vampire_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x107f740
};

