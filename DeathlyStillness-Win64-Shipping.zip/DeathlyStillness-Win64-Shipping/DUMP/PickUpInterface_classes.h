// BlueprintGeneratedClass PickUpInterface.PickUpInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UPickUpInterface_C : UInterface {

	void RenderDeepClose(); // Function PickUpInterface.PickUpInterface_C.RenderDeepClose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void RenderDeepOpen(); // Function PickUpInterface.PickUpInterface_C.RenderDeepOpen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
	void Pickup(); // Function PickUpInterface.PickUpInterface_C.Pickup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x107f740
};

